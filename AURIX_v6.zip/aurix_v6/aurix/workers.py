from __future__ import annotations

from .common import *  # noqa: F401,F403


class DiagnosticsWorker(QThread):
    completed = Signal(dict)

    def __init__(self, settings: dict[str, Any]) -> None:
        super().__init__()
        self.settings = settings

    def run(self) -> None:
        base = normalize_base_url(str(self.settings.get("local_base_url", "")))
        result: dict[str, Any] = {
            "server_online": False,
            "model_id": "Not detected",
            "model_owner": "Not reported",
            "error": "",
            "internet_online": False,
            "perception_online": False,
            "perception_model_id": "Not configured",
            "perception_error": "",
        }
        try:
            if not is_loopback_api(base):
                raise ValueError("The main model endpoint must be local: http://127.0.0.1, http://localhost or http://[::1].")
            r = requests.get(f"{base}/models", timeout=4)
            r.raise_for_status()
            body = r.json()
            models = body.get("data", []) if isinstance(body, dict) else []
            result["server_online"] = True
            if models and isinstance(models, list):
                first = models[0] if isinstance(models[0], dict) else {}
                result["model_id"] = str(first.get("id") or "Model ID not reported")
                result["model_owner"] = str(first.get("owned_by") or "Not reported")
            else:
                result["model_id"] = "Server online; no model ID returned"
        except requests.RequestException as exc:
            result["error"] = f"{type(exc).__name__}: {exc}"
        except (ValueError, TypeError, json.JSONDecodeError) as exc:
            result["error"] = str(exc)

        perception_base = normalize_base_url(str(self.settings.get("perception_base_url", "")))
        if perception_base:
            try:
                if not is_loopback_api(perception_base):
                    raise ValueError("Vision endpoint must use local HTTP on localhost / 127.0.0.1 / ::1.")
                vr = requests.get(f"{perception_base}/models", timeout=3)
                vr.raise_for_status()
                vbody = vr.json()
                vmodels = vbody.get("data", []) if isinstance(vbody, dict) else []
                result["perception_online"] = True
                if vmodels and isinstance(vmodels, list) and isinstance(vmodels[0], dict):
                    result["perception_model_id"] = str(vmodels[0].get("id") or "Model ID not reported")
                else:
                    result["perception_model_id"] = "Server online; no model ID returned"
            except (requests.RequestException, ValueError, TypeError, json.JSONDecodeError) as exc:
                result["perception_error"] = str(exc)

        # This check sends no chat content; it only tests whether a public endpoint is reachable.
        try:
            net = requests.get("https://www.gstatic.com/generate_204", timeout=3, allow_redirects=True)
            result["internet_online"] = net.status_code in (200, 204)
        except requests.RequestException:
            result["internet_online"] = False
        self.completed.emit(result)


class ChatWorker(QThread):
    succeeded = Signal(str, str, str)  # answer, backend, returned model id
    failed = Signal(str)
    token = Signal(str)

    def __init__(self, messages: list[dict[str, str]], settings: dict[str, Any], backend: str, model_id: str = "") -> None:
        super().__init__()
        self.messages = messages
        self.settings = settings
        self.backend = backend
        self.model_id = model_id

    def run(self) -> None:
        try:
            if self.backend == "local":
                base = normalize_base_url(str(self.settings.get("local_base_url", "")))
                if not is_loopback_api(base):
                    raise RuntimeError("The main local model endpoint must use localhost / 127.0.0.1 / ::1 over HTTP.")
                override = str(self.settings.get("local_model", "auto")).strip()
                model = (self.model_id or "") if override.lower() == "auto" else override
                if not model:
                    raise RuntimeError("The local API did not report a model ID. Open /v1/models or set a Model ID override in Configuration.")
                api_key = "no-key-required"
                model_context = (
                    f"The app is configured to use a local llamafile-compatible server. "
                    f"The model ID reported by that server is: {model}. "
                    "This ID identifies the server's loaded model entry; it does not by itself prove which GPU, "
                    "cloud provider, or physical hardware is being used."
                )
            else:
                base = normalize_base_url(str(self.settings.get("cloud_base_url", "")))
                model = str(self.settings.get("cloud_model", "")).strip()
                api_key = os.getenv("AURIX_CLOUD_API_KEY", "").strip()
                model_context = "This request is being answered by the configured cloud API provider."
                if not bool(self.settings.get("cloud_enabled", False)):
                    raise RuntimeError("Cloud fallback is disabled in AURIX settings.")
                if not base or not model or not api_key:
                    raise RuntimeError(
                        "Cloud fallback is not fully configured. Set the cloud endpoint, model ID, enable hybrid mode, "
                        "and provide AURIX_CLOUD_API_KEY in the Windows environment."
                    )

            if not base:
                raise RuntimeError("The API base URL is empty. Open Settings and correct it.")

            memory_context = str(self.settings.get("_memory_context", "")).strip() if self.backend == "local" else ""
            memory_instruction = ("\n\nUSER-APPROVED LOCAL MEMORY (treat as possibly outdated context; ask if uncertain):\n" + memory_context) if memory_context else ""
            web_context = str(self.settings.get("_web_context", "")).strip() if self.backend == "local" else ""
            web_instruction = ("\n\n" + web_context) if web_context else ""
            system_prompt = (
                "You are AURIX, a practical desktop AI assistant. Be honest about your capabilities. "
                "You cannot browse the internet yourself; AURIX fetches web results for you only when the user starts a message with 'search'. "
                "When a WEB SEARCH RESULTS block is provided, base current-events claims only on it and cite sources as [n]. "
                "If the user needs current information and no results are provided, tell them to start the message with 'search'. "
                "You cannot directly control the computer. A separate action planner "
                "can propose a small allow-listed action plan, but the human must approve each action before execution. "
                "Never claim an action happened unless a tool confirms it. Do not claim to be NVIDIA, made by NVIDIA, "
                "running on NVIDIA hardware, or connected to a cloud service unless verified evidence is supplied. "
                "If asked who made the model and the information is unavailable, say you cannot reliably identify "
                "the model's creator from the chat alone. Distinguish model identity, inference server, hardware, "
                "and internet connectivity. Never pretend to self-update or learn model weights. " + model_context + memory_instruction + web_instruction
            )
            payload_messages = [{"role": "system", "content": system_prompt}]
            payload_messages.extend(self.messages[-24:])
            response = requests.post(
                f"{base}/chat/completions",
                headers={"Content-Type": "application/json", "Authorization": f"Bearer {api_key}"},
                json={"model": model, "messages": payload_messages, "temperature": 0.65, "stream": True},
                timeout=(10, int(self.settings.get("request_timeout_seconds", 180))),
                stream=True,
            )
            response.raise_for_status()
            response_model = model
            if "event-stream" in response.headers.get("content-type", "").lower():
                parts: list[str] = []
                for raw in response.iter_lines():
                    if self.isInterruptionRequested():
                        break
                    line = raw.decode("utf-8", "replace").strip() if raw else ""
                    if not line.startswith("data:"):
                        continue
                    chunk = line[5:].strip()
                    if chunk == "[DONE]":
                        break
                    try:
                        obj = json.loads(chunk)
                    except json.JSONDecodeError:
                        continue
                    response_model = str(obj.get("model") or response_model)
                    choices = obj.get("choices") or []
                    delta = ((choices[0].get("delta") or {}).get("content") or "") if choices else ""
                    if delta:
                        parts.append(delta)
                        self.token.emit(delta)
                answer = "".join(parts)
            else:
                data = response.json()
                answer = data["choices"][0]["message"]["content"]
                response_model = str(data.get("model") or model)
            response.close()
            if self.isInterruptionRequested():
                return
            answer = clean_reply(answer) if isinstance(answer, str) else ""
            if not answer:
                raise RuntimeError("The model returned an empty response.")
            self.succeeded.emit(answer, self.backend, response_model)
        except requests.exceptions.ConnectionError as exc:
            self.failed.emit(
                f"Could not connect to the {self.backend} AI server. Check that it is running and that the API URL is correct.\n\n{exc}"
            )
        except requests.exceptions.Timeout:
            self.failed.emit(f"The {self.backend} AI request timed out. Try a smaller model or a longer timeout.")
        except requests.exceptions.HTTPError as exc:
            detail = exc.response.text[:700] if exc.response is not None else ""
            self.failed.emit(f"The {self.backend} server returned an HTTP error: {exc}\n{detail}")
        except (KeyError, IndexError, TypeError, ValueError) as exc:
            self.failed.emit(f"The {self.backend} server returned an unexpected response: {exc}")
        except Exception as exc:
            self.failed.emit(f"{type(exc).__name__}: {exc}")


class ActionPlanWorker(QThread):
    completed = Signal(dict)
    failed = Signal(str)

    def __init__(self, instruction: str, settings: dict[str, Any], detected_model_id: str) -> None:
        super().__init__()
        self.instruction = instruction
        self.settings = settings
        self.detected_model_id = detected_model_id

    def run(self) -> None:
        try:
            base = normalize_base_url(str(self.settings.get("local_base_url", "")))
            if not is_loopback_api(base):
                raise RuntimeError("The action planner must use the local AI endpoint.")
            override = str(self.settings.get("local_model", "auto")).strip()
            model = self.detected_model_id if override.lower() == "auto" else override
            if not model:
                r = requests.get(f"{base}/models", timeout=5)
                r.raise_for_status()
                entries = r.json().get("data", [])
                model = str(entries[0].get("id", "")) if entries else ""
            if not model:
                raise RuntimeError("No local model ID was returned by /v1/models.")
            system = (
                "You are AURIX's action planner. You NEVER execute anything. Return only valid JSON with keys "
                "summary and actions. Propose at most three actions. The only allowed action types are: "
                "search_web with a short query; open_url with a complete http/https URL; launch_app with app "
                "exactly one of Calculator, Notepad, Paint. Do not propose shell commands, scripts, terminal use, "
                "file deletion, file modification, messaging, purchases, administrator actions, credential access, "
                "or any other action. If a request cannot be represented safely by these tools, return an empty "
                "actions array and explain in summary. User approval is required for every action. "
                'JSON example: {"summary":"Open a calculator","actions":[{"type":"launch_app","app":"Calculator","reason":"The user asked to open it"}]}'
            )
            response = requests.post(
                f"{base}/chat/completions",
                headers={"Content-Type": "application/json", "Authorization": "Bearer no-key-required"},
                json={
                    "model": model,
                    "messages": [
                        {"role": "system", "content": system},
                        {"role": "user", "content": self.instruction[:2000]},
                    ],
                    "temperature": 0.1,
                },
                timeout=int(self.settings.get("request_timeout_seconds", 180)),
            )
            response.raise_for_status()
            raw = response.json()["choices"][0]["message"]["content"]
            if not isinstance(raw, str):
                raise ValueError("The model returned a non-text action plan.")
            self.completed.emit(parse_action_plan(raw))
        except requests.exceptions.RequestException as exc:
            self.failed.emit(f"Could not reach the local model for action planning: {exc}")
        except (KeyError, IndexError, TypeError, ValueError, json.JSONDecodeError) as exc:
            self.failed.emit(f"Could not validate the action plan: {exc}")
        except Exception as exc:
            self.failed.emit(f"{type(exc).__name__}: {exc}")


class WebSearchWorker(QThread):
    completed = Signal(str, list)
    failed = Signal(str)

    def __init__(self, query: str) -> None:
        super().__init__()
        self.query = query

    def run(self) -> None:
        try:
            response = requests.get(
                "https://html.duckduckgo.com/html/",
                params={"q": self.query},
                headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AURIX/0.4"},
                timeout=18,
            )
            response.raise_for_status()
            # BeautifulSoup is a small dependency used only to parse public search results.
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(response.text, "html.parser")
            results: list[dict[str, str]] = []
            for anchor in soup.select("a.result__a")[:8]:
                title = anchor.get_text(" ", strip=True)
                href = str(anchor.get("href", ""))
                if href.startswith("//"):
                    href = "https:" + href
                parsed = urlparse(href)
                if "duckduckgo.com" in (parsed.hostname or ""):
                    target = parse_qs(parsed.query).get("uddg", [""])[0]
                    href = unquote(target)
                clean = safe_http_url(href)
                if not clean or not title:
                    continue
                container = anchor.find_parent(class_="result") or anchor.parent
                snippet_node = container.select_one(".result__snippet") if container else None
                snippet = snippet_node.get_text(" ", strip=True) if snippet_node else ""
                results.append({"title": title[:220], "url": clean, "snippet": snippet[:500]})
            self.completed.emit(self.query, results)
        except requests.exceptions.RequestException as exc:
            self.failed.emit(f"Web search failed: {exc}")
        except Exception as exc:
            self.failed.emit(f"Could not read search results: {exc}")


class ImageAnalysisWorker(QThread):
    completed = Signal(str, str)
    failed = Signal(str)

    def __init__(self, image_path: Path, settings: dict[str, Any], question: str) -> None:
        super().__init__()
        self.image_path = image_path
        self.settings = settings
        self.question = question

    def run(self) -> None:
        try:
            base = normalize_base_url(str(self.settings.get("perception_base_url", "")))
            if not is_loopback_api(base):
                raise RuntimeError("The visual model endpoint must be local: http://127.0.0.1 or http://localhost.")
            if not self.image_path.exists():
                raise FileNotFoundError("The selected image no longer exists.")
            raw = self.image_path.read_bytes()
            if len(raw) > 10 * 1024 * 1024:
                raise RuntimeError("Image is larger than 10 MB. Choose a smaller image or resize it first.")
            mime = mimetypes.guess_type(self.image_path.name)[0] or "image/png"
            if not mime.startswith("image/"):
                raise RuntimeError("The selected file is not a supported image.")
            model_override = str(self.settings.get("perception_model", "auto")).strip()
            if model_override.lower() == "auto":
                model_response = requests.get(f"{base}/models", timeout=5)
                model_response.raise_for_status()
                models = model_response.json().get("data", [])
                model = str(models[0].get("id", "")) if models and isinstance(models[0], dict) else ""
            else:
                model = model_override
            if not model:
                raise RuntimeError("The local vision server did not report a model ID. Check /v1/models or set an override.")
            data_url = f"data:{mime};base64,{base64.b64encode(raw).decode('ascii')}"
            payload = {
                "model": model,
                "messages": [
                    {"role": "system", "content": "You are AURIX's local visual perception module. Describe only what is visible. Be precise about uncertainty. Do not infer sensitive personal traits or identify people."},
                    {"role": "user", "content": [
                        {"type": "text", "text": self.question[:1200]},
                        {"type": "image_url", "image_url": {"url": data_url}},
                    ]},
                ],
                "temperature": 0.2,
                "max_tokens": 800,
            }
            response = requests.post(
                f"{base}/chat/completions",
                headers={"Content-Type": "application/json", "Authorization": "Bearer no-key-required"},
                json=payload,
                timeout=int(self.settings.get("request_timeout_seconds", 180)),
            )
            response.raise_for_status()
            body = response.json()
            content = body["choices"][0]["message"]["content"]
            if isinstance(content, list):
                content = "\n".join(str(part.get("text", "")) for part in content if isinstance(part, dict))
            if not isinstance(content, str) or not content.strip():
                raise RuntimeError("The visual model returned an empty response.")
            self.completed.emit(content.strip(), str(body.get("model") or model))
        except requests.exceptions.RequestException as exc:
            self.failed.emit(f"Local vision API request failed: {exc}\nConfirm that a multimodal-compatible server is running on the configured port.")
        except Exception as exc:
            self.failed.emit(f"{type(exc).__name__}: {exc}")


class VoiceInputWorker(QThread):
    """Short, user-triggered offline dictation through Vosk + sounddevice."""
    transcript = Signal(str)
    failed = Signal(str)
    status = Signal(str)

    def __init__(self, model_path: str, max_seconds: int = 14) -> None:
        super().__init__()
        self.model_path = Path(model_path).expanduser()
        self.max_seconds = max_seconds
        self.stop_event = threading.Event()

    def stop(self) -> None:
        self.stop_event.set()

    def run(self) -> None:
        try:
            import sounddevice as sd
            from vosk import Model, KaldiRecognizer, SetLogLevel
            if not self.model_path.is_dir():
                raise RuntimeError(
                    "Offline speech model not found. Run download_voice_model.ps1, then set its folder in Configuration."
                )
            SetLogLevel(-1)
            model = Model(str(self.model_path))
            recognizer = KaldiRecognizer(model, 16000)
            self.status.emit("LISTENING · AUDIO STAYS ON THIS PC")
            final_parts: list[str] = []
            speech_started = False
            last_voice = time.monotonic()
            started = time.monotonic()
            with sd.RawInputStream(samplerate=16000, blocksize=4000, dtype="int16", channels=1) as stream:
                while not self.stop_event.is_set() and time.monotonic() - started < self.max_seconds:
                    data, overflowed = stream.read(4000)
                    raw = bytes(data)
                    if not raw:
                        continue
                    # Low-cost RMS estimate to detect the end of speech without online services.
                    count = len(raw) // 2
                    if count:
                        import struct
                        samples = struct.unpack("<" + "h" * count, raw[:count * 2])
                        rms = (sum(sample * sample for sample in samples) / count) ** 0.5
                        if rms > 260:
                            speech_started = True
                            last_voice = time.monotonic()
                    if recognizer.AcceptWaveform(raw):
                        piece = json.loads(recognizer.Result()).get("text", "").strip()
                        if piece:
                            final_parts.append(piece)
                            speech_started = True
                            last_voice = time.monotonic()
                    if speech_started and time.monotonic() - last_voice > 1.35:
                        break
            tail = json.loads(recognizer.FinalResult()).get("text", "").strip()
            if tail:
                final_parts.append(tail)
            transcript = " ".join(final_parts).strip()
            if transcript:
                self.transcript.emit(transcript)
            else:
                self.failed.emit("I didn't catch any speech. Check your microphone and try again.")
        except ImportError:
            self.failed.emit("Voice dependencies are missing. Run install_voice_features.bat and try again.")
        except Exception as exc:
            self.failed.emit(f"Offline voice input failed: {type(exc).__name__}: {exc}")


class WakeWordWorker(QThread):
    """Optional local wake-word detector. Microphone is open only while explicitly enabled."""
    detected = Signal()
    failed = Signal(str)
    status = Signal(str)

    def __init__(self, model_path: str, threshold: float = 0.58) -> None:
        super().__init__()
        self.model_path = Path(model_path).expanduser()
        self.threshold = threshold
        self.stop_event = threading.Event()

    def stop(self) -> None:
        self.stop_event.set()

    def run(self) -> None:
        try:
            import numpy as np
            import sounddevice as sd
            from openwakeword.model import Model
            if not self.model_path.is_file():
                raise RuntimeError("Choose an openWakeWord ONNX model file in Configuration before enabling wake-word mode.")
            detector = Model(wakeword_models=[str(self.model_path)], inference_framework="onnx")
            self.status.emit("WAKE WORD ACTIVE · MICROPHONE IN USE")
            triggered = False
            with sd.RawInputStream(samplerate=16000, blocksize=1280, dtype="int16", channels=1) as stream:
                while not self.stop_event.is_set():
                    data, overflowed = stream.read(1280)
                    if not data:
                        continue
                    frame = np.frombuffer(bytes(data), dtype=np.int16)
                    scores = detector.predict(frame)
                    score = max((float(v) for v in scores.values()), default=0.0)
                    if score >= self.threshold:
                        triggered = True
                        break
            if triggered and not self.stop_event.is_set():
                self.detected.emit()
        except ImportError:
            self.failed.emit("Wake-word dependencies are missing. Run install_voice_features.bat.")
        except Exception as exc:
            self.failed.emit(f"Wake-word listener stopped: {type(exc).__name__}: {exc}")


class UpdateWorker(QThread):
    completed = Signal(dict)
    failed = Signal(str)

    def __init__(self, manifest_url: str) -> None:
        super().__init__()
        self.manifest_url = manifest_url.strip()

    def run(self) -> None:
        try:
            parsed = urlparse(self.manifest_url)
            if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password:
                raise RuntimeError("Update manifest must be a valid HTTPS URL without embedded credentials.")
            response = requests.get(self.manifest_url, timeout=15)
            response.raise_for_status()
            if urlparse(response.url).scheme != "https":
                raise RuntimeError("The update manifest redirected away from HTTPS; the request was rejected.")
            manifest = response.json()
            if not isinstance(manifest, dict):
                raise RuntimeError("Update manifest must be a JSON object.")
            version = str(manifest.get("version", "")).strip()
            if (len(version) > 32 or not version or len(version.split(".")) > 4
                    or any(not part.isdigit() for part in version.split("."))):
                raise RuntimeError("Update version must contain only 2–4 numeric dot-separated parts, such as 0.4.1.")
            zip_url = str(manifest.get("zip_url", "")).strip()
            expected = str(manifest.get("sha256", "")).lower().strip()
            parsed_zip = urlparse(zip_url)
            if (not version or parsed_zip.scheme != "https" or not parsed_zip.hostname
                    or parsed_zip.username or parsed_zip.password or len(expected) != 64
                    or any(ch not in "0123456789abcdef" for ch in expected)):
                raise RuntimeError("Manifest needs version, an HTTPS zip_url, and a 64-character hexadecimal SHA-256 checksum.")
            # Update versions are compared as numeric dotted versions only.
            def parts(value: str) -> tuple[int, ...]:
                return tuple(int(x) for x in value.split(".") if x.isdigit())
            current = parts(APP_VERSION)
            offered = parts(version)
            if not offered or offered <= current:
                self.completed.emit({"available": False, "version": version})
                return
            download = requests.get(zip_url, timeout=35, stream=True)
            download.raise_for_status()
            if urlparse(download.url).scheme != "https":
                raise RuntimeError("The update ZIP redirected away from HTTPS; the download was rejected.")
            blob = bytearray()
            for chunk in download.iter_content(1024 * 256):
                if chunk:
                    blob.extend(chunk)
                    if len(blob) > 150 * 1024 * 1024:
                        raise RuntimeError("Update ZIP exceeds the 150 MB safety limit.")
            actual = hashlib.sha256(blob).hexdigest()
            if actual != expected:
                raise RuntimeError("Update checksum does not match the manifest. The archive was rejected.")
            staging_root = APP_DIR / "update_staging" / version
            if staging_root.exists():
                shutil.rmtree(staging_root)
            staging_root.mkdir(parents=True, exist_ok=True)
            archive_path = staging_root / "update.zip"
            archive_path.write_bytes(blob)
            with zipfile.ZipFile(archive_path) as zf:
                bad = zf.testzip()
                if bad:
                    raise RuntimeError(f"Update ZIP failed integrity testing at {bad}.")
                infos = zf.infolist()
                if len(infos) > 5000 or sum(item.file_size for item in infos) > 500 * 1024 * 1024:
                    raise RuntimeError("Update ZIP exceeds the file-count or expanded-size safety limit.")
                for info in infos:
                    member = PurePosixPath(info.filename)
                    windows_member = PureWindowsPath(info.filename)
                    if (member.is_absolute() or windows_member.is_absolute() or windows_member.drive
                            or ".." in member.parts or ".." in windows_member.parts
                            or info.filename.startswith(("/", "\\"))):
                        raise RuntimeError("Update ZIP contains an unsafe path and was rejected.")
                extract_root = staging_root / "package"
                extract_root.mkdir(exist_ok=True)
                zf.extractall(extract_root)
            self.completed.emit({"available": True, "version": version, "path": str(extract_root), "sha256": actual})
        except requests.RequestException as exc:
            self.failed.emit(f"Update check/download failed: {exc}")
        except (ValueError, OSError, zipfile.BadZipFile, json.JSONDecodeError) as exc:
            self.failed.emit(f"Could not process update: {exc}")
        except Exception as exc:
            self.failed.emit(f"Update manager: {type(exc).__name__}: {exc}")


