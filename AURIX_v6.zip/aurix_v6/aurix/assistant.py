"""AURIX v6 behaviour: chat flow, live speech, floating orb + tray, proactive events."""
from __future__ import annotations

from PySide6.QtCore import QEvent
from PySide6.QtGui import QIcon, QPixmap, QRadialGradient
from PySide6.QtWidgets import QApplication, QSystemTrayIcon

from .blob import FloatingOrb, Toast
from .common import *  # noqa: F401,F403
from .dialogs import AssistantSettingsDialog
from .proactive import ProactiveEngine
from .speech import SpeechEngine, speakable
from .workers import ChatWorker, WebSearchWorker


class AssistantMixin:
    # ------------------------------------------------------------------ setup
    def _init_assistant(self) -> None:
        self.feed: list[dict] = []
        self.unread = 0
        self._quitting = False
        self._tray_told = False
        self._tts_ready = False
        self._ui_busy = False
        self._gen = 0
        self._spoken_upto = 0
        self._orphans: list = []

        self.speech = SpeechEngine(self)
        self._apply_speech_settings()
        self.speech.speaking_changed.connect(self._on_speaking)
        self.speech.failed.connect(lambda m: self._log_activity(m[:60]))
        self.speech.ready.connect(self._on_speech_ready)

        self.orb = FloatingOrb()
        self.toast = Toast()
        self.orb.activated.connect(self._show_main)
        self.toast.clicked.connect(self._show_main)
        self.orb.moved.connect(self._remember_orb_pos)
        self.orb.menu_requested.connect(lambda pos: self.orb_menu.exec(pos))
        self._build_menu_and_tray()

        self.proactive = ProactiveEngine(lambda: self.settings, save_settings, self)
        self.proactive.event.connect(self._on_proactive_event)
        self.proactive.weather_updated.connect(self._on_weather)
        self.proactive.news_updated.connect(self._on_news)
        self.proactive.health_updated.connect(self._on_health)
        self.proactive.status.connect(self._on_proactive_status)
        self.clock_timer = QTimer(self)
        self.clock_timer.timeout.connect(self._refresh_hero)
        self.clock_timer.start(20000)
        self._refresh_hero()
        self._render_feed()
        QTimer.singleShot(1200, self.speech.warmup)
        QTimer.singleShot(11000, self._check_tts_ready)
        self.proactive.start()

    def _apply_speech_settings(self) -> None:
        self.speech.rate = int(self.settings.get("tts_rate", 0))
        self.speech.voice = str(self.settings.get("tts_voice", ""))

    def _build_menu_and_tray(self) -> None:
        self.orb_menu = QMenu()
        self.orb_menu.addAction("Open AURIX", self._show_main)
        self.orb_menu.addAction("Brief me now", self._brief_now)
        self.mute_action = self.orb_menu.addAction("Mute voice")
        self.mute_action.setCheckable(True)
        self.mute_action.toggled.connect(self._toggle_mute)
        self.orb_menu.addAction("Test voice", self._test_voice)
        self.orb_menu.addSeparator()
        self.orb_menu.addAction("Quit AURIX", self._quit_app)
        self.tray = None
        if QSystemTrayIcon.isSystemTrayAvailable():
            pm = QPixmap(64, 64)
            pm.fill(Qt.transparent)
            p = QPainter(pm)
            p.setRenderHint(QPainter.Antialiasing)
            g = QRadialGradient(QPointF(32, 32), 30)
            g.setColorAt(0, QColor(255, 255, 255))
            g.setColorAt(0.35, QColor(94, 240, 255))
            g.setColorAt(1, QColor(80, 60, 200))
            p.setBrush(g)
            p.setPen(Qt.NoPen)
            p.drawEllipse(QPointF(32, 32), 28, 28)
            p.end()
            self.tray = QSystemTrayIcon(QIcon(pm), self)
            self.tray.setToolTip("AURIX — personal intelligence")
            self.tray.setContextMenu(self.orb_menu)
            self.tray.activated.connect(lambda r: self._show_main() if r == QSystemTrayIcon.Trigger else None)
            self.tray.show()

    # ------------------------------------------------------------ orb / window
    def _remember_orb_pos(self, x: int, y: int) -> None:
        self.settings["orb_pos"] = [x, y]
        save_settings(self.settings)

    def _hide_to_orb(self, notify: bool = False) -> None:
        self.hide()
        if self.settings.get("orb_enabled", True):
            pos = self.settings.get("orb_pos")
            if isinstance(pos, list) and len(pos) == 2:
                self.orb.move(int(pos[0]), int(pos[1]))
            else:
                self.orb.place_default()
            self.orb.show()
            self.orb.pulse()
        if notify and self.tray is not None and not self._tray_told:
            self._tray_told = True
            self.tray.showMessage("AURIX is still running", "Click the floating orb to reopen. Right-click it for the menu or to quit.", QSystemTrayIcon.Information, 4000)

    def _show_main(self) -> None:
        self.orb.hide()
        self.toast.hide()
        self.orb.set_badge(0)
        self.showNormal()
        self.raise_()
        self.activateWindow()

    def changeEvent(self, event) -> None:  # noqa: N802
        super().changeEvent(event)
        if (event.type() == QEvent.WindowStateChange and self.isMinimized() and not self._quitting
                and self.settings.get("orb_enabled", True)):
            QTimer.singleShot(0, self._hide_to_orb)

    def closeEvent(self, event) -> None:  # noqa: N802
        if not self._quitting and self.settings.get("orb_enabled", True):
            event.ignore()
            self._hide_to_orb(notify=True)
            return
        self._shutdown()
        event.accept()
        QApplication.quit()

    def _quit_app(self) -> None:
        self._quitting = True
        self.close()

    def _shutdown(self) -> None:
        self.diag_timer.stop()
        self.clock_timer.stop()
        self.speech.shutdown()
        for worker in (self.voice_worker, self.wake_worker):
            if worker is not None and worker.isRunning():
                stop = getattr(worker, "stop", None)
                if callable(stop):
                    stop()
        workers = [self.current_worker, self.chat_search_worker, self.web_worker, self.diagnostics_worker, self.plan_worker,
                   self.image_worker, self.update_worker, self.voice_worker, self.wake_worker, *self._orphans]
        for w in workers:
            if w is not None and w.isRunning():
                w.requestInterruption()
        self.proactive.stop_workers()
        for w in workers:
            if w is not None and w.isRunning() and not w.wait(2500):
                w.terminate()
                w.wait(500)
        self.orb.close()
        self.toast.close()
        if self.tray is not None:
            self.tray.hide()

    # ------------------------------------------------------------------ voice
    def _on_speaking(self, speaking: bool) -> None:
        self.core.set_speaking(speaking)
        self.orb.set_speaking(speaking)
        if speaking:
            self.core.fire("voice")

    def _on_speech_ready(self, ok: bool) -> None:
        if ok and not self._tts_ready:
            self._tts_ready = True
            self._log_activity("Voice output ready (Windows speech)")
            self.core.set_available("voice", True)

    def _check_tts_ready(self) -> None:
        if not self._tts_ready:
            self.core.set_available("voice", False)
            self._log_activity("Voice output did not start (Windows only)")

    def _toggle_mute(self, muted: bool) -> None:
        self.speech.enabled = not muted
        if muted:
            self.speech.stop()
        self._log_activity("Voice output muted" if muted else "Voice output on")

    def _set_speak_replies(self, enabled: bool) -> None:
        self.settings["speak_replies"] = bool(enabled)
        save_settings(self.settings)
        if not enabled:
            self.speech.stop()

    def _stop_speech(self) -> None:
        self.speech.stop()

    def _speak_reply(self, text: str) -> None:
        if self.speak_check.isChecked():
            self.speech.say(text)

    def _test_voice(self) -> None:
        if not SpeechEngine.available():
            QMessageBox.information(self, "AURIX voice", "Voice output uses Windows' built-in speech and is not available on this system.")
            return
        self.speech.enabled = not self.mute_action.isChecked()
        if not self.speech.enabled:
            self.mute_action.setChecked(False)
        if not self.speech.say("Voice check. I am AURIX, and my voice is working."):
            self._log_activity("Voice test failed to start")

    def _live_speak(self, final: bool = False) -> None:
        """Speak finished sentences while the reply is still streaming."""
        if not self.speak_check.isChecked():
            return
        text = clean_reply(self.stream_text, False)
        seg = text[self._spoken_upto:]
        if not seg.strip():
            return
        if final:
            cut = len(seg)
        else:
            marks = list(re.finditer(r"[.!?:;]\s|\n", seg))
            if not marks:
                return
            cut = marks[-1].end()
        if text[: self._spoken_upto + cut].count("```") % 2 and not final:
            return  # inside a code block: wait until it closes
        chunk = seg[:cut]
        if not final and len(speakable(chunk)) < 25:
            return
        self._spoken_upto += cut
        self.speech.say(chunk)

    # ------------------------------------------------------------- chat flow
    def _busy(self) -> bool:
        return self._ui_busy

    def _set_busy_ui(self, busy: bool) -> None:
        self._ui_busy = busy
        self.composer.setEnabled(not busy)
        self.send_btn.setText("■  STOP" if busy else "SEND  ↗")
        self.send_btn.setProperty("stop", busy)
        self.send_btn.style().unpolish(self.send_btn)
        self.send_btn.style().polish(self.send_btn)
        if not busy:
            self.composer.setFocus()

    def _orphan(self, worker) -> None:
        if worker is not None and worker.isRunning():
            worker.requestInterruption()
            self._orphans.append(worker)
        self._orphans = [w for w in self._orphans if w.isRunning()]

    def _send_message(self) -> None:
        if self._ui_busy:
            self._stop_generation()
            return
        text = self.composer.toPlainText().strip()
        if not text:
            return
        self.speech.stop()
        self.memory.add_message(self.current_session, "user", text)
        self.composer.clear()
        self.pending_messages = self.memory.get_messages(self.current_session)
        self.pending_sources = []
        self._set_busy_ui(True)
        self.tab_chat.setChecked(True)
        self._on_tab(0)
        query = detect_search_intent(text)
        if query:
            self._render_messages(self.pending_messages, live="")
            self._start_chat_search(query)
        else:
            self._begin_local_chat("")
        self._refresh_sessions()

    def _stop_generation(self) -> None:
        self._gen += 1
        self._orphan(self.current_worker)
        self._orphan(self.chat_search_worker)
        self.speech.stop()
        partial = clean_reply(self.stream_text, False) if self._stream_active else ""
        self._stream_active = False
        self._stream_timer.stop()
        self.core.set_busy(None)
        if partial:
            self.memory.add_message(self.current_session, "assistant", partial + "\n\n_(stopped)_")
        self.pending_sources = []
        self._render_messages(self.memory.get_messages(self.current_session))
        self._set_busy_ui(False)
        self._set_status("STOPPED", "neutral")
        self._log_activity("Generation stopped by you")

    def _start_chat_search(self, query: str) -> None:
        gen = self._gen
        self._log_activity(f"Web search (you asked) · {query[:34]}")
        self._set_status("SEARCHING PUBLIC WEB RESULTS", "working")
        self.core.set_busy("web")
        self.core.pulse()
        self.chat_search_worker = WebSearchWorker(query)
        self.chat_search_worker.completed.connect(lambda q, r, g=gen: self._on_chat_search_done(q, r) if g == self._gen else None)
        self.chat_search_worker.failed.connect(lambda e, g=gen: self._on_chat_search_failed(e) if g == self._gen else None)
        self.chat_search_worker.start()

    def _on_chat_search_done(self, query: str, results: list) -> None:
        self.pending_sources = list(results[:6])
        self._log_activity(f"Web search returned {len(results)} result(s)")
        self._begin_local_chat(build_web_context(query, results))

    def _on_chat_search_failed(self, error: str) -> None:
        self._log_activity("Web search failed; answering without it")
        self._begin_local_chat("WEB SEARCH FAILED: " + error[:300] + " Tell the user the search failed and answer only from general knowledge, clearly marked as possibly outdated.")

    def _begin_local_chat(self, web_context: str) -> None:
        self.stream_text = ""
        self._spoken_upto = 0
        self._stream_active = True
        self._render_messages(self.pending_messages, live="")
        self._set_status("LOCAL MODEL PROCESSING", "working")
        self._log_activity("Request routed to local llamafile" + (" with web results" if web_context else ""))
        self.core.set_busy("chat")
        if self.memory.memory_context():
            self.core.fire("memory")
        self._start_worker("local", web_context)

    def _on_token(self, delta: str) -> None:
        self.stream_text += delta
        if not self._stream_timer.isActive():
            self._stream_timer.start(70)

    def _render_stream(self) -> None:
        if self._stream_active:
            self._render_messages(self.pending_messages, live=clean_reply(self.stream_text, False))
            self._live_speak()

    def _start_worker(self, backend: str, web_context: str = "") -> None:
        worker_settings = self.settings.copy()
        if backend == "local":
            worker_settings["_memory_context"] = self.memory.memory_context()
            worker_settings["_web_context"] = web_context
        gen = self._gen
        w = ChatWorker(self.pending_messages, worker_settings, backend, self.detected_model_id if backend == "local" else "")
        w.succeeded.connect(lambda a, b, c, g=gen: self._on_success(a, b, c) if g == self._gen else None)
        w.token.connect(lambda d, g=gen: self._on_token(d) if g == self._gen else None)
        w.failed.connect(lambda e, g=gen, ub=backend: self._on_failure(e, ub) if g == self._gen else None)
        self.current_worker = w
        w.start()

    def _on_success(self, answer: str, backend: str, returned_model: str) -> None:
        self._stream_timer.stop()
        if not self.stream_text.strip():
            self.stream_text = answer
        self._live_speak(final=True)
        self._stream_active = False
        self.core.set_busy(None)
        self.core.fire("chat")
        if backend == "local" and self.pending_sources:
            links = "\n".join("- [%s](%s)" % (re.sub(r"[\[\]]", "", s_["title"])[:80], s_["url"].replace(")", "%29")) for s_ in self.pending_sources)
            answer = answer + "\n\n**Sources**\n" + links
        self.pending_sources = []
        self.memory.add_message(self.current_session, "assistant", answer)
        self._render_messages(self.memory.get_messages(self.current_session))
        self._set_busy_ui(False)
        self.memory_value.setText(str(self.memory.message_count()))
        if backend == "cloud":
            self._set_status("ANSWERED BY APPROVED CLOUD MODEL", "cloud")
            self._log_activity(f"Approved cloud response · {returned_model[:25]}")
        else:
            self._set_status("ANSWERED BY LOCAL MODEL API", "neutral")
            self._log_activity(f"Local response received · {returned_model[:28]}")
        self._refresh_sessions()

    def _on_failure(self, error: str, backend: str) -> None:
        self._stream_active = False
        self._stream_timer.stop()
        self.core.set_busy(None)
        self.speech.stop()
        self._render_messages(self.pending_messages)
        if backend == "local":
            if self._cloud_configuration_state() == "READY · APPROVAL":
                answer = QMessageBox.question(
                    self, "Local model unavailable",
                    "AURIX couldn't reach the local model. Do you approve sending this message and the recent conversation context to your configured cloud provider?\n\nNo content is sent unless you choose Yes.",
                    QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
                if answer == QMessageBox.Yes:
                    self._set_status("WAITING FOR APPROVED CLOUD RESPONSE", "working")
                    self._stream_active = True
                    self._start_worker("cloud")
                    return
            self._set_busy_ui(False)
            QMessageBox.warning(self, "Local AI unavailable", error)
            self._set_status("LOCAL MODEL NEEDS ATTENTION", "error")
            self._log_activity("Local inference request failed")
        else:
            self._set_busy_ui(False)
            QMessageBox.warning(self, "Cloud AI unavailable", error)
            self._set_status("CLOUD REQUEST FAILED", "error")
            self._log_activity("Cloud request failed")
        self.refresh_diagnostics()

    # ------------------------------------------------------------- proactive
    def _on_proactive_event(self, kind: str, title: str, text: str, speak: bool) -> None:
        self.feed.insert(0, {"time": datetime.now().strftime("%I:%M %p").lstrip("0"), "kind": kind, "title": title, "text": text})
        del self.feed[80:]
        if not self.tab_feed.isChecked():
            self.unread += 1
            self.tab_feed.setText(f"FEED · {self.unread}")
        self._render_feed()
        channel = {"briefing": "chat", "weather": "weather", "news": "news", "health": "health", "wellness": "health"}.get(kind, "memory")
        for target in (self.core, self.orb):
            target.fire(channel, True)
            target.pulse()
        self._log_activity(title[:36])
        if speak:
            self.speech.say(f"{title}. {text}")
        if not self.isVisible():
            self.orb.set_badge(self.orb.badge + 1)
            self.toast.show_message(title, text, self.orb)

    def _on_proactive_status(self, message: str) -> None:
        self._log_activity(message[:48])
        key = "weather" if message.lower().startswith("weather") else "news"
        self.core.set_available(key, False)

    def _brief_now(self) -> None:
        self.tab_feed.setChecked(True)
        self._on_tab(1)
        self.proactive.briefing()

    def _toggle_proactive(self, enabled: bool) -> None:
        self.settings["proactive_enabled"] = bool(enabled)
        save_settings(self.settings)
        self._log_activity("Proactive mode " + ("on" if enabled else "off"))
        if enabled:
            self.proactive.refresh_weather()
            self.proactive.refresh_news()

    def _open_assistant_settings(self) -> None:
        dialog = AssistantSettingsDialog(self.settings, self)
        if dialog.exec() == QDialog.Accepted:
            self.settings = dialog.get_settings()
            save_settings(self.settings)
            self._apply_speech_settings()
            self.speech.stop()
            self.proactive_check.blockSignals(True)
            self.proactive_check.setChecked(bool(self.settings.get("proactive_enabled", True)))
            self.proactive_check.blockSignals(False)
            self._refresh_hero()
            self.proactive.refresh_weather()
            self.proactive.refresh_news()
            self._log_activity("Assistant settings updated")
