from __future__ import annotations

from .common import *  # noqa: F401,F403
from .dialogs import *  # noqa: F401,F403
from .workers import *  # noqa: F401,F403
from .ui_build import UiMixin
from .assistant import AssistantMixin


class AurixWindow(UiMixin, AssistantMixin, QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle(f"AURIX {APP_VERSION} · Personal Intelligence")
        self.setMinimumSize(1360, 800)
        self.resize(1600, 960)
        self.settings = load_settings()
        self.memory = MemoryStore()
        self.current_session = self.memory.create_session()
        self.current_worker: ChatWorker | None = None
        self.diagnostics_worker: DiagnosticsWorker | None = None
        self.plan_worker: ActionPlanWorker | None = None
        self.web_worker: WebSearchWorker | None = None
        self.image_worker: ImageAnalysisWorker | None = None
        self.pending_messages: list[dict[str, str]] = []
        self.detected_model_id = ""
        self.last_diag: dict[str, Any] = {}
        self.voice_worker = None
        self.wake_worker = None
        self.speech_worker = None
        self.update_worker = None
        self.chat_search_worker = None
        self.pending_sources: list[dict[str, str]] = []
        self.stream_text = ""
        self._stream_active = False
        self._stream_timer = QTimer(self)
        self._stream_timer.setSingleShot(True)
        self._stream_timer.timeout.connect(self._render_stream)
        self._build_ui()
        self.neural = self.core
        self._init_assistant()
        self._refresh_sessions()
        self._render_messages([])
        self._log_activity("AURIX v6 core online")
        self.voice_card[1].setText("READY" if Path(str(self.settings.get("voice_model_path", ""))).is_dir() else "MODEL NEEDED")
        self.voice_card[2].setText("Vosk offline STT")
        self.saved_memory_value.setText(str(len(self.memory.list_memories())))
        self._set_status("DISCOVERING LOCAL CORE", "working")
        QTimer.singleShot(250, self.refresh_diagnostics)
        self.diag_timer = QTimer(self)
        self.diag_timer.timeout.connect(lambda: self.refresh_diagnostics(silent=True))
        self.diag_timer.start(25000)
        if bool(self.settings.get("wakeword_enabled", False)) and str(self.settings.get("wakeword_model_path", "")):
            QTimer.singleShot(900, lambda: self.wake_btn.setChecked(True))

    def _set_status(self, text: str, mode: str = "neutral") -> None:
        self.header_status.setText(text)
        self.core.set_thinking(mode == "working")
        self.orb.set_thinking(mode == "working")
        if mode == "working":
            self.header_status.setStyleSheet("background:#352b15;color:#f5d98b;border:1px solid #80682a;border-radius:9px;padding:7px 10px;font-size:7pt;font-weight:800;")
        elif mode == "cloud":
            self.header_status.setStyleSheet("background:#2b2040;color:#d7bcff;border:1px solid #674b88;border-radius:9px;padding:7px 10px;font-size:7pt;font-weight:800;")
        elif mode == "error":
            self.header_status.setStyleSheet("background:#3a1d29;color:#ffbac7;border:1px solid #814052;border-radius:9px;padding:7px 10px;font-size:7pt;font-weight:800;")
        else:
            self.header_status.setStyleSheet("")

    def _log_activity(self, message: str) -> None:
        stamp = datetime.now().strftime("%H:%M:%S")
        self.activity.insertItem(0, f"{stamp}   {message}")
        while self.activity.count() > 18:
            self.activity.takeItem(self.activity.count() - 1)

    def _refresh_sessions(self) -> None:
        self.sessions.blockSignals(True)
        self.sessions.clear()
        for row in self.memory.list_sessions():
            item = QListWidgetItem(row["title"])
            item.setData(Qt.UserRole, row["id"])
            self.sessions.addItem(item)
            if row["id"] == self.current_session:
                self.sessions.setCurrentItem(item)
        self.sessions.blockSignals(False)
        self.memory_value.setText(str(self.memory.message_count()))

    def _render_messages(self, messages: list[dict[str, str]], live: str | None = None) -> None:
        bar = self.chat_view.verticalScrollBar()
        stick = bar.value() >= bar.maximum() - 40 or live is not None or not messages
        chunks = ["<html><body style='background:transparent;color:#d9f2f8;font-family:Segoe UI,Arial,sans-serif;font-size:10pt;'>"]
        if not messages and live is None:
            tiles = [("think", "THINK", "Ask the local model anything"), ("perceive", "PERCEIVE", "Capture or analyze a screenshot"),
                     ("research", "RESEARCH", "Search the web · or type: search <topic>"), ("act", "ACT", "Plan an action, approve each step")]
            chunks.append("<div style='color:#f2fcff;font-size:17pt;font-weight:600;margin:10px 2px 4px;'>Systems standing by.</div>"
                          "<div style='color:#7f9fb1;font-size:9pt;margin:0 2px 16px;'>Your model runs on this machine. Start a message with <b>search</b> and AURIX reads live web results for you.</div>")
            for key, name, text in tiles:
                chunks.append(f"<a href='aurix:{key}' style='text-decoration:none;'><table width='100%' cellspacing='0' cellpadding='0' style='margin-bottom:8px;'><tr>"
                              "<td width='3' bgcolor='#5ef0ff'></td><td bgcolor='#0b1726' style='padding:10px 13px;'>"
                              f"<span style='color:#5ef0ff;font-size:7pt;font-weight:800;letter-spacing:1.5px;'>{name}</span><br>"
                              f"<span style='color:#cfe6ee;'>{text}</span></td></tr></table></a>")
        for message in messages:
            if message["role"] == "user":
                content = html.escape(message["content"]).replace("\n", "<br>")
                chunks.append("<table width='100%' cellspacing='0' cellpadding='0' style='margin:12px 0 4px;'><tr><td width='60'></td>"
                              "<td bgcolor='#10283a' style='padding:11px 14px;'><span style='color:#8fb8c8;font-size:7pt;font-weight:800;letter-spacing:1.4px;'>YOU</span><br>"
                              f"<span style='color:#eefcff;'>{content}</span></td></tr></table>")
            else:
                chunks.append(self._ai_bubble(md_to_html(message["content"])))
        if live is not None:
            chunks.append(self._ai_bubble(md_to_html(live) if live else "<span style='color:#a99dff;'>● ● ●</span>"))
        chunks.append("</body></html>")
        self.chat_view.setHtml("".join(chunks))
        if stick:
            bar.setValue(bar.maximum())

    @staticmethod
    def _ai_bubble(body: str) -> str:
        return ("<table width='100%' cellspacing='0' cellpadding='0' style='margin:12px 0 4px;'><tr><td width='3' bgcolor='#8b7bff'></td>"
                "<td bgcolor='#0b1522' style='padding:11px 14px;'><span style='color:#a99dff;font-size:7pt;font-weight:800;letter-spacing:1.4px;'>AURIX</span><br>"
                f"<span style='color:#d8eaf0;'>{body}</span></td><td width='30'></td></tr></table>")

    def _on_chat_link(self, url: QUrl) -> None:
        if url.scheme() in ("http", "https"):
            safe = safe_http_url(url.toString())
            if safe:
                QDesktopServices.openUrl(QUrl(safe))
            return
        action = url.path() or url.toString().split(":", 1)[-1]
        {"think": self.composer.setFocus, "perceive": self._capture_screen, "research": self._ask_web_search, "act": self._plan_action}.get(action, lambda: None)()

    def _session_menu(self, pos) -> None:
        item = self.sessions.itemAt(pos)
        if item is None:
            return
        menu = QMenu(self)
        delete = menu.addAction("Delete session")
        if menu.exec(self.sessions.mapToGlobal(pos)) is delete:
            sid = item.data(Qt.UserRole)
            self.memory.delete_session(sid)
            if sid == self.current_session:
                self.current_session = self.memory.create_session()
                self._render_messages([])
            self._refresh_sessions()
            self._log_activity("Session deleted from local memory")

    def _new_conversation(self) -> None:
        self.current_session = self.memory.create_session()
        self._refresh_sessions()
        self._render_messages([])
        self.composer.setFocus()
        self._log_activity("New command session created")

    def _select_session(self, item: QListWidgetItem) -> None:
        sid = item.data(Qt.UserRole)
        if sid:
            self.current_session = sid
            self._render_messages(self.memory.get_messages(sid))
            self._log_activity("Session loaded from local memory")

    def _open_memory(self) -> None:
        dialog = MemoryDialog(self.memory, self)
        dialog.exec()
        self.saved_memory_value.setText(str(len(self.memory.list_memories())))
        self._log_activity("Local memory vault opened")
        self.neural.fire("memory")

    def _start_voice_input(self) -> None:
        self.speech.stop()
        if getattr(self, "voice_worker", None) is not None and self.voice_worker.isRunning():
            self.voice_worker.stop()
            self.voice_btn.setText("◉  Voice")
            return
        if getattr(self, "wake_worker", None) is not None and self.wake_worker.isRunning():
            # Release the microphone for dictation, then re-arm the wake listener afterward.
            self.wake_worker.stop()
            self.wake_worker.wait(1500)
        model_path = str(self.settings.get("voice_model_path", ""))
        self.voice_btn.setText("■  Stop")
        self.neural.fire("voice")
        self.voice_card[1].setText("LISTENING")
        self.voice_card[2].setText("Offline microphone capture · no upload")
        self._set_status("OFFLINE VOICE INPUT ACTIVE", "working")
        self._log_activity("User started offline voice input")
        self.voice_worker = VoiceInputWorker(model_path)
        self.voice_worker.transcript.connect(self._on_voice_transcript)
        self.voice_worker.failed.connect(self._on_voice_failed)
        self.voice_worker.status.connect(lambda value: self.voice_card[2].setText(value))
        self.voice_worker.finished.connect(self._voice_worker_finished)
        self.voice_worker.start()

    def _voice_worker_finished(self) -> None:
        self.voice_btn.setEnabled(True)
        self.voice_btn.setText("◉  Voice")
        if self.wake_btn.isChecked():
            self.voice_card[1].setText("WAKE WORD ACTIVE")
            self.voice_card[2].setText("Microphone active locally while enabled")
            QTimer.singleShot(900, self._start_wake_worker)
        else:
            self.voice_card[1].setText("READY" if Path(str(self.settings.get("voice_model_path", ""))).is_dir() else "MODEL NEEDED")
            self.voice_card[2].setText("Vosk offline STT")

    def _on_voice_transcript(self, transcript: str) -> None:
        current = self.composer.toPlainText().strip()
        self.composer.setPlainText((current + " " + transcript).strip())
        self.composer.setFocus()
        if self.settings.get("voice_autosend", False) and not self._ui_busy and self.composer.toPlainText().strip():
            self._log_activity("Voice transcribed and sent (auto-send on)")
            self._send_message()
            return
        self._set_status("VOICE TRANSCRIBED · REVIEW BEFORE SENDING", "neutral")
        self._log_activity("Offline speech transcribed into the draft; not sent automatically")

    def _on_voice_failed(self, error: str) -> None:
        self._set_status("VOICE INPUT NEEDS ATTENTION", "error")
        self._log_activity("Offline voice input failed")
        QMessageBox.warning(self, "AURIX voice input", error)

    def _toggle_wake_word(self, enabled: bool) -> None:
        self.settings["wakeword_enabled"] = bool(enabled)
        save_settings(self.settings)
        if not enabled:
            if getattr(self, "wake_worker", None) is not None and self.wake_worker.isRunning():
                self.wake_worker.stop()
            if getattr(self, "voice_worker", None) is not None and self.voice_worker.isRunning():
                self.voice_worker.stop()
            self.wake_btn.setText("◎  Wake off")
            self.voice_card[1].setText("READY")
            self.voice_card[2].setText("Microphone closed · voice input is manual")
            self._log_activity("Wake-word listener disabled; microphone released")
            return
        path = str(self.settings.get("wakeword_model_path", "")).strip()
        if not path or not Path(path).is_file():
            self.wake_btn.blockSignals(True)
            self.wake_btn.setChecked(False)
            self.wake_btn.blockSignals(False)
            self.settings["wakeword_enabled"] = False
            save_settings(self.settings)
            QMessageBox.information(self, "Wake-word model required", "Choose a compatible ONNX wake-word model in Configuration first. The microphone will not stay active until you enable this switch.")
            return
        if getattr(self, "voice_worker", None) is not None and self.voice_worker.isRunning():
            self.voice_worker.stop()
        self.wake_btn.setText("◎  Wake on")
        self.voice_card[1].setText("WAKE WORD ACTIVE")
        self.voice_card[2].setText("Microphone active locally while enabled")
        self._start_wake_worker()

    def _start_wake_worker(self) -> None:
        if not self.wake_btn.isChecked():
            return
        if getattr(self, "wake_worker", None) is not None and self.wake_worker.isRunning():
            return
        self.wake_worker = WakeWordWorker(str(self.settings.get("wakeword_model_path", "")))
        self.wake_worker.detected.connect(self._on_wake_detected)
        self.wake_worker.failed.connect(self._on_wake_failed)
        self.wake_worker.start()
        self._log_activity("Local wake-word listener started")

    def _on_wake_detected(self) -> None:
        self._log_activity("Wake word detected locally")
        self.voice_card[1].setText("WAKE WORD HEARD")
        QTimer.singleShot(550, self._start_voice_input)

    def _on_wake_failed(self, error: str) -> None:
        self.wake_btn.setChecked(False)
        self.voice_card[1].setText("WAKE WORD ERROR")
        self.voice_card[2].setText("Microphone released")
        QMessageBox.warning(self, "Wake-word listener", error)

    def _check_updates(self) -> None:
        if getattr(self, "update_worker", None) is not None and self.update_worker.isRunning():
            QMessageBox.information(self, "Update manager", "An update check is already running.")
            return
        manifest = str(self.settings.get("update_manifest_url", "")).strip()
        if not manifest:
            QMessageBox.information(
                self, "Update manager",
                "No release feed is configured yet. AURIX can check and stage updates once you configure an HTTPS JSON manifest in Settings.\n\nThis standalone build does not invent a publisher or silently install code."
            )
            self._log_activity("Update check requested; no manifest URL configured")
            return
        self.update_btn.setEnabled(False)
        self.update_btn.setText("Checking…")
        self._set_status("CHECKING CONFIGURED UPDATE FEED", "working")
        self.update_worker = UpdateWorker(manifest)
        self.update_worker.completed.connect(self._on_update_check)
        self.update_worker.failed.connect(self._on_update_failed)
        self.update_worker.finished.connect(lambda: (self.update_btn.setEnabled(True), self.update_btn.setText("↻   Update manager")))
        self.update_worker.start()

    def _on_update_check(self, data: dict[str, Any]) -> None:
        if not data.get("available"):
            self._set_status("AURIX IS UP TO DATE", "neutral")
            QMessageBox.information(self, "Update manager", f"No newer version was found. Current version: {APP_VERSION}.")
            self._log_activity("Update check completed; no update available")
            return
        path = Path(str(data.get("path", "")))
        self._set_status("UPDATE DOWNLOADED · AWAITING REVIEW", "neutral")
        self._log_activity(f"Update {data.get('version')} downloaded and staged for review")
        answer = QMessageBox.question(
            self, "Update staged",
            f"AURIX {data.get('version')} was checksum-verified and extracted here:\n{path}\n\nNothing has been installed or executed. Open the staging folder for manual review?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes
        )
        if answer == QMessageBox.Yes and path.exists():
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))

    def _on_update_failed(self, error: str) -> None:
        self._set_status("UPDATE CHECK FAILED", "error")
        self._log_activity("Update manager rejected or could not retrieve update")
        QMessageBox.warning(self, "Update manager", error)

    def _open_settings(self) -> None:
        dialog = SettingsDialog(self.settings, self)
        if dialog.exec() == QDialog.Accepted:
            was_wake_enabled = self.wake_btn.isChecked()
            self.settings = dialog.get_settings()
            save_settings(self.settings)
            self.speak_check.setChecked(bool(self.settings.get("speak_replies", True)))
            self._apply_speech_settings()
            self._log_activity("Connection configuration updated")
            self.refresh_diagnostics()
            desired_wake = bool(self.settings.get("wakeword_enabled", False))
            if was_wake_enabled and self.wake_btn.isChecked():
                self.wake_btn.setChecked(False)
            if desired_wake and not self.wake_btn.isChecked():
                self.wake_btn.setChecked(True)
            self.saved_memory_value.setText(str(len(self.memory.list_memories())))
            QMessageBox.information(self, "AURIX configuration", "Settings saved locally. Voice model and update-feed paths are stored on this PC.")

    def _open_runtime_ui(self) -> None:
        base = normalize_base_url(str(self.settings.get("local_base_url", "http://127.0.0.1:8080/v1")))
        if base.endswith("/v1"):
            url = base[:-3]
        else:
            url = base
        QDesktopServices.openUrl(QUrl(url))
        self._log_activity("Opened local runtime web UI")

    def refresh_diagnostics(self, silent: bool = False) -> None:
        if self.diagnostics_worker is not None and self.diagnostics_worker.isRunning():
            return
        if not silent:
            self._set_status("SCANNING LOCAL SYSTEMS", "working")
            self.local_strip[1].setText("CHECKING")
            self.net_strip[1].setText("CHECKING")
        self.diagnostics_worker = DiagnosticsWorker(self.settings.copy())
        self.diagnostics_worker.completed.connect(self._on_diagnostics)
        self.diagnostics_worker.start()

    def _cloud_configuration_state(self) -> str:
        if not self.settings.get("cloud_enabled", False):
            return "DISABLED"
        configured = bool(
            str(self.settings.get("cloud_base_url", "")).strip()
            and str(self.settings.get("cloud_model", "")).strip()
            and os.getenv("AURIX_CLOUD_API_KEY", "").strip()
        )
        return "READY · APPROVAL" if configured else "INCOMPLETE SETUP"

    def _on_diagnostics(self, data: dict[str, Any]) -> None:
        previous_online = bool(self.last_diag.get("server_online", False)) if self.last_diag else None
        previous_internet = bool(self.last_diag.get("internet_online", False)) if self.last_diag else None
        self.last_diag = data
        online = bool(data.get("server_online"))
        internet = bool(data.get("internet_online"))
        discovered = str(data.get("model_id", "")) if online else ""
        self.detected_model_id = "" if discovered in {"", "Not detected", "Model ID not reported", "Server online; no model ID returned"} else discovered
        self.core.set_online(online)
        self.orb.set_online(online)
        self.neural.set_available("chat", online)
        self.local_strip[1].setText("CONNECTED" if online else "OFFLINE")
        self.net_strip[1].setText("ONLINE" if internet else "OFFLINE")
        cloud_state = self._cloud_configuration_state()
        self.cloud_strip[1].setText(cloud_state)
        self.internet_value.setText("ONLINE" if internet else "OFFLINE")
        self.cloud_value.setText(cloud_state)
        self.server_card[1].setText("ONLINE" if online else "OFFLINE")
        self.server_card[1].setStyleSheet("color:#8ff0ce;" if online else "color:#ff9cab;")
        self.server_card[2].setText(safe_host(str(self.settings.get("local_base_url", ""))))
        self.model_card[1].setText(str(data.get("model_id", "Not detected")))
        self.model_card[2].setText(f"API owner tag: {data.get('model_owner', 'Not reported')}")
        vision_online = bool(data.get("perception_online"))
        self.perception_card[1].setText("ONLINE" if vision_online else "OFFLINE")
        self.perception_card[1].setStyleSheet("color:#8ff0ce;" if vision_online else "color:#ffbf7a;")
        self.perception_card[2].setText(str(data.get("perception_model_id", "Not detected")))
        self.accel_value.setText("Not verified")
        for key, ok in (("chat", online), ("web", internet), ("vision", vision_online),
                        ("voice", self._tts_ready or Path(str(self.settings.get("voice_model_path", ""))).is_dir())):
            self.neural.set_available(key, ok)
        busy = self._busy()
        if online:
            if not busy:
                self._set_status("LOCAL CORE ONLINE  ·  OFFLINE-CAPABLE", "neutral")
            if previous_online is not True:
                self._log_activity("Local inference server detected")
            if data.get("model_id") and data.get("model_id") != "Server online; no model ID returned" and data.get("model_id") != getattr(self, "_logged_model", None):
                self._logged_model = data.get("model_id")
                self._log_activity(f"Model ID detected: {str(data['model_id'])[:34]}")
        else:
            if not busy:
                self._set_status("LOCAL CORE OFFLINE", "error")
            if previous_online is not False:
                self._log_activity("Local server not reachable on configured endpoint")
        if previous_internet is not internet:
            self._log_activity("Internet reachable" if internet else "Internet not reachable")

    def _ask_web_search(self) -> None:
        query, ok = QInputDialog.getText(
            self,
            "AURIX · Web research",
            "Search query (this text will be sent to DuckDuckGo; chat and screenshots are not included):",
        )
        if ok and query.strip():
            if self._busy():
                self._log_activity("Busy — wait for the current response before a new search")
                return
            self.composer.setPlainText("search " + query.strip())
            self._send_message()

    def _run_web_search(self, query: str) -> None:
        if self.web_worker is not None and self.web_worker.isRunning():
            QMessageBox.information(self, "Web research", "A search is already running.")
            return
        self._log_activity(f"Web search requested · {query[:38]}")
        self.neural.fire("web")
        self._set_status("SEARCHING PUBLIC WEB RESULTS", "working")
        self.web_worker = WebSearchWorker(query)
        self.web_worker.completed.connect(self._on_web_results)
        self.web_worker.failed.connect(self._on_web_search_failed)
        self.web_worker.start()

    def _on_web_results(self, query: str, results: list) -> None:
        self._set_status("WEB RESULTS READY · OPEN LINKS MANUALLY", "neutral")
        self._log_activity(f"Web search returned {len(results)} result(s)")
        if not results:
            QMessageBox.information(self, "Web research", "No results were returned. Try a shorter or different query.")
            return
        WebResultsDialog(query, results, self).exec()

    def _on_web_search_failed(self, error: str) -> None:
        self._set_status("WEB SEARCH UNAVAILABLE", "error")
        self._log_activity("Web search failed")
        QMessageBox.warning(self, "Web research", error)

    def _capture_screen(self) -> None:
        screen = QApplication.primaryScreen()
        if screen is None:
            QMessageBox.warning(self, "Screen capture", "No desktop screen is available.")
            return
        pixmap = screen.grabWindow(0)
        if pixmap.isNull():
            QMessageBox.warning(self, "Screen capture", "Windows did not provide a screenshot.")
            return
        captures = APP_DIR / "captures"
        captures.mkdir(parents=True, exist_ok=True)
        path = captures / f"screen_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
        if not pixmap.save(str(path), "PNG"):
            QMessageBox.warning(self, "Screen capture", "Could not save the screenshot locally.")
            return
        self._log_activity("Desktop screenshot captured locally")
        self._show_image_preview(path)

    def _choose_image(self) -> None:
        filename, _ = QFileDialog.getOpenFileName(
            self,
            "Choose an image for local analysis",
            str(Path.home()),
            "Images (*.png *.jpg *.jpeg *.webp *.bmp)",
        )
        if filename:
            self._show_image_preview(Path(filename))

    def _show_image_preview(self, image_path: Path) -> None:
        try:
            if image_path.stat().st_size > 10 * 1024 * 1024:
                QMessageBox.warning(self, "Image too large", "AURIX currently accepts images up to 10 MB.")
                return
        except OSError as exc:
            QMessageBox.warning(self, "Image unavailable", str(exc))
            return
        dialog = ImagePreviewDialog(image_path, self)
        dialog.analyze_requested.connect(lambda p=image_path: self._analyze_image(p))
        dialog.exec()

    def _analyze_image(self, image_path: Path) -> None:
        if self.image_worker is not None and self.image_worker.isRunning():
            QMessageBox.information(self, "Visual analysis", "An image analysis is already running.")
            return
        if not is_loopback_api(str(self.settings.get("perception_base_url", ""))):
            QMessageBox.warning(self, "Local vision not configured", "Set the multimodal API base URL to a local endpoint in Configuration.")
            return
        self.image_btn.setEnabled(False)
        self.screen_btn.setEnabled(False)
        self._set_status("LOCAL VISUAL ANALYSIS RUNNING", "working")
        self.neural.fire("vision")
        self._log_activity(f"Image sent to local perception endpoint · {image_path.name[:30]}")
        question = self.composer.toPlainText().strip() or "Describe this screenshot or image and identify any relevant visible details."
        self.image_worker = ImageAnalysisWorker(image_path, self.settings.copy(), question)
        self.image_worker.completed.connect(self._on_image_analysis)
        self.image_worker.failed.connect(self._on_image_analysis_failed)
        self.image_worker.start()

    def _on_image_analysis(self, answer: str, model_id: str) -> None:
        self.image_btn.setEnabled(True)
        self.screen_btn.setEnabled(True)
        self.memory.add_message(self.current_session, "assistant", f"[LOCAL VISUAL ANALYSIS · {model_id}]\n{answer}")
        self._render_messages(self.memory.get_messages(self.current_session))
        self._refresh_sessions()
        self._set_status("LOCAL VISUAL ANALYSIS COMPLETE", "neutral")
        self._log_activity(f"Visual response received · {model_id[:30]}")

    def _on_image_analysis_failed(self, error: str) -> None:
        self.image_btn.setEnabled(True)
        self.screen_btn.setEnabled(True)
        self._set_status("LOCAL VISION NEEDS ATTENTION", "error")
        self._log_activity("Local visual analysis failed")
        QMessageBox.warning(self, "Local visual analysis", error)

    def _plan_action(self) -> None:
        if self.current_worker is not None and self.current_worker.isRunning():
            QMessageBox.information(self, "Action planner", "Wait for the current chat response to finish before planning an action.")
            return
        if self.plan_worker is not None and self.plan_worker.isRunning():
            QMessageBox.information(self, "Action planner", "An action plan is already being prepared.")
            return
        instruction = self.composer.toPlainText().strip()
        if not instruction:
            QMessageBox.information(self, "Action planner", "Type what you want AURIX to do in the message box first, then press PLAN ACTION.")
            return
        self.plan_btn.setEnabled(False)
        self._set_status("BUILDING LOCAL ACTION PLAN", "working")
        self.neural.fire("action")
        self._log_activity("Local model asked to propose an allow-listed action plan")
        self.plan_worker = ActionPlanWorker(instruction, self.settings.copy(), self.detected_model_id)
        self.plan_worker.completed.connect(self._on_action_plan)
        self.plan_worker.failed.connect(self._on_action_plan_failed)
        self.plan_worker.start()

    def _on_action_plan(self, plan: dict[str, Any]) -> None:
        self.plan_btn.setEnabled(True)
        actions = plan.get("actions", [])
        self._set_status("ACTION PLAN READY · AWAITING HUMAN REVIEW", "neutral")
        self._log_activity(f"Action planner proposed {len(actions)} allow-listed action(s)")
        if not actions:
            QMessageBox.information(self, "AURIX action planner", str(plan.get("summary", "No safe actions proposed.")) + "\n\nNo action was executed.")
            return
        dialog = ActionQueueDialog(plan, self)
        dialog.approved.connect(self._execute_approved_action)
        dialog.exec()

    def _on_action_plan_failed(self, error: str) -> None:
        self.plan_btn.setEnabled(True)
        self._set_status("ACTION PLANNING FAILED", "error")
        self._log_activity("Action plan could not be generated")
        QMessageBox.warning(self, "AURIX action planner", error)

    def _execute_approved_action(self, action: dict[str, str]) -> None:
        kind = action.get("type", "")
        if kind == "search_web":
            query = action.get("query", "").strip()[:240]
            if query:
                self._log_activity("Human approved web search")
                self._run_web_search(query)
            return
        if kind == "open_url":
            url = safe_http_url(action.get("url", ""))
            if url:
                opened = QDesktopServices.openUrl(QUrl(url))
                if opened:
                    self._log_activity(f"Human approved browser navigation · {safe_host(url)[:30]}")
                else:
                    QMessageBox.warning(self, "Browser", "Windows could not open this link in the default browser.")
            else:
                QMessageBox.warning(self, "Blocked URL", "AURIX rejected a non-web or malformed URL.")
            return
        if kind == "launch_app":
            allowed = {"Calculator": ["calc.exe"], "Notepad": ["notepad.exe"], "Paint": ["mspaint.exe"]}
            app_name = action.get("app", "")
            command = allowed.get(app_name)
            if not command:
                QMessageBox.warning(self, "Blocked application", "This application is not on AURIX's allow-list.")
                return
            try:
                subprocess.Popen(command, shell=False)
                self._log_activity(f"Human approved launch · {app_name}")
            except OSError as exc:
                QMessageBox.warning(self, "Could not open application", str(exc))
            return
        QMessageBox.warning(self, "Blocked action", "This action type is not supported by AURIX 0.4.")

