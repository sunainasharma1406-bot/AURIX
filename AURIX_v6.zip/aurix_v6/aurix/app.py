from __future__ import annotations

from .common import *  # noqa: F401,F403
from .window import AurixWindow


def main() -> int:
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setApplicationVersion(APP_VERSION)
    app.setFont(QFont("Segoe UI", 9))
    app.setQuitOnLastWindowClosed(False)  # the floating orb keeps AURIX alive when the window is closed
    window = AurixWindow()
    window.show()
    return app.exec()
