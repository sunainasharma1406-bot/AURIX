from __future__ import annotations

from .common import *  # noqa: F401,F403
from PySide6.QtWidgets import QSpinBox


class Composer(QPlainTextEdit):
    send_requested = Signal()

    def keyPressEvent(self, event: QKeyEvent) -> None:  # noqa: N802 - Qt API name
        if event.key() in (Qt.Key_Return, Qt.Key_Enter) and event.modifiers() & Qt.ControlModifier:
            self.send_requested.emit()
            return
        super().keyPressEvent(event)


class SettingsDialog(QDialog):
    def __init__(self, settings: dict[str, Any], parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle("AURIX · Configuration")
        self.setMinimumWidth(590)
        self.settings = settings.copy()
        layout = QVBoxLayout(self)
        layout.setContentsMargins(22, 22, 22, 22)
        layout.setSpacing(14)
        heading = QLabel("CONNECTION CONFIGURATION")
        heading.setObjectName("dialogEyebrow")
        layout.addWidget(heading)
        form = QFormLayout()
        form.setHorizontalSpacing(18)
        form.setVerticalSpacing(12)
        self.local_url = QLineEdit(str(settings.get("local_base_url", "")))
        self.local_model = QLineEdit(str(settings.get("local_model", "auto")))
        self.cloud_url = QLineEdit(str(settings.get("cloud_base_url", "")))
        self.cloud_model = QLineEdit(str(settings.get("cloud_model", "")))
        self.perception_url = QLineEdit(str(settings.get("perception_base_url", "http://127.0.0.1:8081/v1")))
        self.perception_model = QLineEdit(str(settings.get("perception_model", "auto")))
        self.timeout = QLineEdit(str(settings.get("request_timeout_seconds", 180)))
        self.voice_model_path = QLineEdit(str(settings.get("voice_model_path", "")))
        voice_row = QHBoxLayout()
        voice_row.addWidget(self.voice_model_path, 1)
        voice_browse = QPushButton("Browse")
        voice_browse.clicked.connect(self._browse_voice_model)
        voice_row.addWidget(voice_browse)
        self.wakeword_model_path = QLineEdit(str(settings.get("wakeword_model_path", "")))
        wake_row = QHBoxLayout()
        wake_row.addWidget(self.wakeword_model_path, 1)
        wake_browse = QPushButton("Browse")
        wake_browse.clicked.connect(self._browse_wake_model)
        wake_row.addWidget(wake_browse)
        self.update_manifest_url = QLineEdit(str(settings.get("update_manifest_url", "")))
        self.wakeword_enabled = QCheckBox("Enable wake-word listener (microphone stays active while enabled)")
        self.wakeword_enabled.setChecked(bool(settings.get("wakeword_enabled", False)))
        self.speak_replies = QCheckBox("Speak assistant replies using offline Windows voices")
        self.speak_replies.setChecked(bool(settings.get("speak_replies", True)))
        self.cloud_enabled = QCheckBox("Enable optional cloud fallback")
        self.cloud_enabled.setChecked(bool(settings.get("cloud_enabled", False)))
        form.addRow("Local API base URL", self.local_url)
        form.addRow("Model ID override", self.local_model)
        form.addRow("Cloud API base URL", self.cloud_url)
        form.addRow("Cloud model ID", self.cloud_model)
        form.addRow("Local vision API base URL", self.perception_url)
        form.addRow("Vision model ID override", self.perception_model)
        form.addRow("Request timeout (seconds)", self.timeout)
        form.addRow("Offline Vosk model folder", voice_row)
        form.addRow("Wake-word ONNX model file", wake_row)
        form.addRow("Update manifest HTTPS URL", self.update_manifest_url)
        form.addRow("Wake-word mode", self.wakeword_enabled)
        form.addRow("Voice output", self.speak_replies)
        form.addRow("Hybrid mode", self.cloud_enabled)
        layout.addLayout(form)
        note = QLabel(
            "Model ID override: leave as ‘auto’ to use the exact ID returned by the local server's /v1/models endpoint. "
            "Cloud fallback is only attempted after local failure and always requires a separate approval. "
            "The cloud API key is read from AURIX_CLOUD_API_KEY and is not saved in this app. "
            "The main and vision endpoints are restricted to localhost. Voice input uses Vosk locally; voice output uses Windows SAPI via pyttsx3. "
            "Wake-word mode requires an ONNX model file and keeps the microphone active only while the switch is enabled. "
            "Screenshots go only to the configured localhost vision API after you press Analyze locally. "
            "Update downloads require an HTTPS manifest containing version, zip_url and sha256; updates are staged for manual review, never silently installed."
        )
        note.setObjectName("mutedNote")
        note.setWordWrap(True)
        layout.addWidget(note)
        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def _browse_voice_model(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, "Select Vosk model folder", self.voice_model_path.text() or str(Path.home()))
        if folder:
            self.voice_model_path.setText(folder)

    def _browse_wake_model(self) -> None:
        filename, _ = QFileDialog.getOpenFileName(self, "Select openWakeWord ONNX model", str(Path.home()), "ONNX models (*.onnx)")
        if filename:
            self.wakeword_model_path.setText(filename)

    def get_settings(self) -> dict[str, Any]:
        try:
            timeout = max(15, min(900, int(self.timeout.text().strip())))
        except ValueError:
            timeout = 180
        self.settings.update({
            "local_base_url": normalize_base_url(self.local_url.text()),
            "local_model": self.local_model.text().strip() or "auto",
            "cloud_base_url": normalize_base_url(self.cloud_url.text()),
            "cloud_model": self.cloud_model.text().strip(),
            "perception_base_url": normalize_base_url(self.perception_url.text()),
            "perception_model": self.perception_model.text().strip() or "auto",
            "cloud_enabled": self.cloud_enabled.isChecked(),
            "request_timeout_seconds": timeout,
            "voice_model_path": self.voice_model_path.text().strip(),
            "wakeword_model_path": self.wakeword_model_path.text().strip(),
            "wakeword_enabled": self.wakeword_enabled.isChecked(),
            "speak_replies": self.speak_replies.isChecked(),
            "update_manifest_url": self.update_manifest_url.text().strip(),
        })
        return self.settings


class WebResultsDialog(QDialog):
    def __init__(self, query: str, results: list[dict[str, str]], parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle("AURIX · Web research")
        self.resize(760, 540)
        layout = QVBoxLayout(self)
        heading = QLabel("WEB RESEARCH RESULTS")
        heading.setObjectName("dialogEyebrow")
        layout.addWidget(heading)
        note = QLabel(f"Query sent to DuckDuckGo: {query}\nResults are untrusted external content. Open only sources you choose.")
        note.setObjectName("mutedNote")
        note.setWordWrap(True)
        layout.addWidget(note)
        self.items = QListWidget()
        self.items.setObjectName("activityList")
        for result in results:
            item = QListWidgetItem(f"{result['title']}\n{result['url']}\n{result['snippet']}")
            item.setData(Qt.UserRole, result["url"])
            self.items.addItem(item)
        layout.addWidget(self.items, 1)
        buttons = QHBoxLayout()
        self.open_btn = QPushButton("OPEN SELECTED IN BROWSER")
        self.open_btn.clicked.connect(self._open_selected)
        close_btn = QPushButton("CLOSE")
        close_btn.clicked.connect(self.accept)
        buttons.addWidget(self.open_btn)
        buttons.addStretch(1)
        buttons.addWidget(close_btn)
        layout.addLayout(buttons)
        self.items.itemDoubleClicked.connect(lambda _item: self._open_selected())
        self.open_btn.setEnabled(bool(results))

    def _open_selected(self) -> None:
        item = self.items.currentItem()
        if not item:
            return
        url = safe_http_url(str(item.data(Qt.UserRole) or ""))
        if url:
            opened = QDesktopServices.openUrl(QUrl(url))
            if not opened:
                QMessageBox.warning(self, "Browser", "Windows could not open this link in the default browser.")


class ImagePreviewDialog(QDialog):
    analyze_requested = Signal()

    def __init__(self, image_path: Path, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.image_path = image_path
        self.setWindowTitle("AURIX · Local visual inspection")
        self.resize(900, 650)
        layout = QVBoxLayout(self)
        eyebrow = QLabel("VISUAL INPUT / REVIEW BEFORE ANALYSIS")
        eyebrow.setObjectName("dialogEyebrow")
        layout.addWidget(eyebrow)
        preview = QLabel()
        preview.setAlignment(Qt.AlignCenter)
        preview.setMinimumSize(640, 390)
        preview.setStyleSheet("background:#06111b;border:1px solid #174356;border-radius:10px;")
        pixmap = QPixmap(str(image_path))
        if pixmap.isNull():
            preview.setText("Could not load this image.")
        else:
            preview.setPixmap(pixmap.scaled(840, 470, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        layout.addWidget(preview, 1)
        note = QLabel(
            f"File: {image_path.name}\nThe image stays on this PC unless you press ANALYZE LOCALLY. "
            "AURIX accepts only a localhost vision API; it does not send screenshots to a cloud service. "
            "Check the preview for private information before proceeding."
        )
        note.setObjectName("mutedNote")
        note.setWordWrap(True)
        layout.addWidget(note)
        buttons = QHBoxLayout()
        analyze = QPushButton("ANALYZE LOCALLY")
        analyze.setObjectName("transmitButton")
        analyze.clicked.connect(self._analyze)
        close = QPushButton("CLOSE")
        close.clicked.connect(self.reject)
        buttons.addStretch(1)
        buttons.addWidget(analyze)
        buttons.addWidget(close)
        layout.addLayout(buttons)

    def _analyze(self) -> None:
        self.analyze_requested.emit()
        self.accept()


class MemoryDialog(QDialog):
    def __init__(self, memory: MemoryStore, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.memory = memory
        self.setWindowTitle("AURIX · Local memory")
        self.resize(620, 480)
        layout = QVBoxLayout(self)
        heading = QLabel("YOUR APPROVED MEMORY")
        heading.setObjectName("dialogEyebrow")
        layout.addWidget(heading)
        note = QLabel("Only items you explicitly save here are included as context in local conversations. Nothing is uploaded by this feature.")
        note.setObjectName("mutedNote")
        note.setWordWrap(True)
        layout.addWidget(note)
        self.list = QListWidget()
        self.list.setObjectName("activityList")
        layout.addWidget(self.list, 1)
        controls = QHBoxLayout()
        add = QPushButton("ADD MEMORY")
        remove = QPushButton("DELETE SELECTED")
        close = QPushButton("DONE")
        controls.addWidget(add)
        controls.addWidget(remove)
        controls.addStretch(1)
        controls.addWidget(close)
        layout.addLayout(controls)
        add.clicked.connect(self._add)
        remove.clicked.connect(self._delete)
        close.clicked.connect(self.accept)
        self._refresh()

    def _refresh(self) -> None:
        self.list.clear()
        for row in self.memory.list_memories():
            item = QListWidgetItem(f"{row['content']}\nSaved {row['created_at']}")
            item.setData(Qt.UserRole, int(row["id"]))
            self.list.addItem(item)

    def _add(self) -> None:
        value, ok = QInputDialog.getMultiLineText(self, "Add local memory", "What should AURIX remember?")
        if ok and value.strip():
            try:
                self.memory.add_memory(value)
                self._refresh()
            except ValueError as exc:
                QMessageBox.warning(self, "Memory", str(exc))

    def _delete(self) -> None:
        item = self.list.currentItem()
        if item is None:
            return
        answer = QMessageBox.question(self, "Delete memory", "Delete this saved memory from the local database?", QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if answer == QMessageBox.Yes:
            self.memory.delete_memory(int(item.data(Qt.UserRole)))
            self._refresh()


class ActionQueueDialog(QDialog):
    approved = Signal(dict)

    def __init__(self, plan: dict[str, Any], parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle("AURIX · Action approval queue")
        self.resize(680, 470)
        layout = QVBoxLayout(self)
        heading = QLabel("SUPERVISED ACTION QUEUE")
        heading.setObjectName("dialogEyebrow")
        layout.addWidget(heading)
        summary = QLabel(str(plan.get("summary", "Proposed actions")))
        summary.setObjectName("mutedNote")
        summary.setWordWrap(True)
        layout.addWidget(summary)
        warning = QLabel("Nothing has happened yet. Approve actions one at a time. Closing this window rejects nothing and executes nothing.")
        warning.setObjectName("mutedNote")
        warning.setWordWrap(True)
        layout.addWidget(warning)
        self.rows = QVBoxLayout()
        self.rows.setSpacing(9)
        layout.addLayout(self.rows)
        self.count_label = QLabel("")
        self.count_label.setObjectName("microLabel")
        layout.addWidget(self.count_label)
        close = QPushButton("CLOSE QUEUE")
        close.clicked.connect(self.reject)
        layout.addWidget(close, alignment=Qt.AlignRight)
        self.remaining = 0
        for action in plan.get("actions", []):
            self._add_action(action)
        self._update_count()

    def _add_action(self, action: dict[str, str]) -> None:
        row = QFrame()
        row.setObjectName("metricCard")
        row_layout = QHBoxLayout(row)
        row_layout.setContentsMargins(12, 10, 12, 10)
        detail = QVBoxLayout()
        kind = action.get("type", "action").replace("_", " ").upper()
        title = QLabel(kind)
        title.setObjectName("sectionLabel")
        if action.get("type") == "search_web":
            description = action.get("query", "")
        elif action.get("type") == "open_url":
            description = action.get("url", "")
        else:
            description = action.get("app", "")
        body = QLabel(description + (("\n" + action["reason"]) if action.get("reason") else ""))
        body.setObjectName("mutedNote")
        body.setWordWrap(True)
        detail.addWidget(title)
        detail.addWidget(body)
        row_layout.addLayout(detail, 1)
        approve = QPushButton("APPROVE")
        approve.setObjectName("transmitButton")
        reject = QPushButton("REJECT")
        row_layout.addWidget(approve)
        row_layout.addWidget(reject)
        self.rows.addWidget(row)
        self.remaining += 1
        approve.clicked.connect(lambda _checked=False, a=action, r=row: self._approve(a, r))
        reject.clicked.connect(lambda _checked=False, r=row: self._remove(r))

    def _approve(self, action: dict[str, str], row: QFrame) -> None:
        self.approved.emit(action)
        self._remove(row)

    def _remove(self, row: QFrame) -> None:
        self.rows.removeWidget(row)
        row.setParent(None)
        row.deleteLater()
        self.remaining -= 1
        self._update_count()
        if self.remaining <= 0:
            self.accept()

    def _update_count(self) -> None:
        self.count_label.setText(f"{self.remaining} ACTION(S) AWAITING YOUR DECISION")




class AssistantSettingsDialog(QDialog):
    """v6: personal details, proactive features, voice output and the floating orb."""

    TOGGLES = [
        ("proactive_enabled", "Proactive mode (AURIX tells you things on its own)"),
        ("proactive_speak", "Speak proactive alerts aloud"),
        ("briefing_on_start", "Give a spoken briefing shortly after AURIX starts"),
        ("weather_enabled", "Weather and air quality (sends only your city's coordinates to Open-Meteo)"),
        ("news_enabled", "Live headlines (public Google News RSS feeds)"),
        ("news_alerts", "Alert me when new headlines appear"),
        ("health_alerts", "PC health alerts (battery, memory, disk, CPU)"),
        ("wellness_enabled", "Wellness reminders (breaks, water, late-night)"),
        ("voice_autosend", "Send voice-dictated messages automatically"),
        ("orb_enabled", "Floating orb + tray icon when the window is closed or minimised"),
    ]

    def __init__(self, settings: dict[str, Any], parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle("AURIX · Assistant")
        self.setMinimumWidth(560)
        self.settings = settings.copy()
        lay = QVBoxLayout(self)
        lay.setContentsMargins(22, 22, 22, 22)
        lay.setSpacing(12)
        head = QLabel("ASSISTANT")
        head.setObjectName("dialogEyebrow")
        lay.addWidget(head)
        form = QFormLayout()
        form.setVerticalSpacing(10)
        self.name = QLineEdit(str(settings.get("user_name", "")))
        self.place = QLineEdit(str(settings.get("weather_place", "")))
        self.voice = QLineEdit(str(settings.get("tts_voice", "")))
        self.voice.setPlaceholderText("blank = Windows default, e.g. Microsoft Zira Desktop")
        self.rate = QSpinBox()
        self.rate.setRange(-10, 10)
        self.rate.setValue(int(settings.get("tts_rate", 0)))
        self.brk = QSpinBox()
        self.brk.setRange(20, 180)
        self.brk.setSuffix(" min")
        self.brk.setValue(int(settings.get("break_minutes", 50)))
        self.qs = QSpinBox()
        self.qs.setRange(0, 23)
        self.qs.setValue(int(settings.get("quiet_start", 23)))
        self.qe = QSpinBox()
        self.qe.setRange(0, 23)
        self.qe.setValue(int(settings.get("quiet_end", 7)))
        form.addRow("Your name", self.name)
        form.addRow("City for weather", self.place)
        form.addRow("Voice name", self.voice)
        form.addRow("Voice speed (-10…10)", self.rate)
        form.addRow("Break reminder every", self.brk)
        form.addRow("Quiet hours start (24h)", self.qs)
        form.addRow("Quiet hours end (24h)", self.qe)
        lay.addLayout(form)
        self.boxes: dict[str, QCheckBox] = {}
        for key, label in self.TOGGLES:
            cb = QCheckBox(label)
            cb.setChecked(bool(settings.get(key, True if key != "voice_autosend" else False)))
            self.boxes[key] = cb
            lay.addWidget(cb)
        note = QLabel("Weather and news contact public services only while enabled. Quiet hours keep alerts visual (no speech).")
        note.setObjectName("mutedNote")
        note.setWordWrap(True)
        lay.addWidget(note)
        bb = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)

    def get_settings(self) -> dict[str, Any]:
        place = self.place.text().strip() or "Kalyan"
        if place != self.settings.get("weather_place"):
            self.settings["weather_lat"] = self.settings["weather_lon"] = None
        self.settings.update({"user_name": self.name.text().strip(), "weather_place": place, "tts_voice": self.voice.text().strip(),
                              "tts_rate": self.rate.value(), "break_minutes": self.brk.value(),
                              "quiet_start": self.qs.value(), "quiet_end": self.qe.value()})
        for key, cb in self.boxes.items():
            self.settings[key] = cb.isChecked()
        return self.settings
