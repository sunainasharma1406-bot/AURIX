"""Live text-to-speech for AURIX v6.

Replaces the old pyttsx3 worker. A single PowerShell process hosts System.Speech (built into Windows)
and speaks one line per command, so replies can be spoken sentence by sentence while the model is still
streaming. Stopping simply kills the process; it is restarted on the next utterance.
"""
from __future__ import annotations

import base64
import re
import subprocess
import sys
import threading

from PySide6.QtCore import QObject, Signal

_PS_SCRIPT = r"""
[Console]::InputEncoding = [System.Text.Encoding]::UTF8
Add-Type -AssemblyName System.Speech
$s = New-Object System.Speech.Synthesis.SpeechSynthesizer
$s.SetOutputToDefaultAudioDevice()
[Console]::Out.WriteLine('READY'); [Console]::Out.Flush()
while ($true) {
  $l = [Console]::In.ReadLine()
  if ($l -eq $null) { break }
  if ($l.StartsWith('R:')) { try { $s.Rate = [int]$l.Substring(2) } catch {} }
  elseif ($l.StartsWith('V:')) { try { $s.SelectVoice($l.Substring(2)) } catch {} }
  elseif ($l.StartsWith('S:')) { try { $s.Speak($l.Substring(2)) } catch {}; [Console]::Out.WriteLine('DONE'); [Console]::Out.Flush() }
}
"""


def speakable(text: str) -> str:
    """Strip Markdown, code, links and reasoning tags so only natural prose is read aloud."""
    text = re.sub(r"<think>.*?</think>", " ", text, flags=re.S | re.I)
    text = re.sub(r"```.*?```", " ", text, flags=re.S)
    text = re.sub(r"\[([^\]]*)\]\([^)]*\)", r"\1", text)
    text = re.sub(r"https?://\S+", " ", text)
    text = re.sub(r"[*#`_>|~]", " ", text)
    text = re.sub(r"^\s*[-•]\s+", "", text, flags=re.M)
    return re.sub(r"\s+", " ", text).strip()


class SpeechEngine(QObject):
    speaking_changed = Signal(bool)
    ready = Signal(bool)
    failed = Signal(str)

    def __init__(self, parent: QObject | None = None) -> None:
        super().__init__(parent)
        self.rate = 0
        self.voice = ""
        self.enabled = True
        self._proc: subprocess.Popen | None = None
        self._pending = 0
        self._lock = threading.Lock()

    @staticmethod
    def available() -> bool:
        return sys.platform.startswith("win")

    @property
    def speaking(self) -> bool:
        return self._pending > 0

    def _command(self) -> list[str]:
        encoded = base64.b64encode(_PS_SCRIPT.encode("utf-16-le")).decode("ascii")
        return ["powershell.exe", "-NoLogo", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-EncodedCommand", encoded]

    def _send(self, line: str) -> bool:
        try:
            assert self._proc is not None and self._proc.stdin is not None
            self._proc.stdin.write((line.replace("\r", " ").replace("\n", " ") + "\n").encode("utf-8"))
            self._proc.stdin.flush()
            return True
        except (OSError, ValueError, AssertionError):
            return False

    def _ensure(self) -> bool:
        if self._proc is not None and self._proc.poll() is None:
            return True
        try:
            flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            self._proc = subprocess.Popen(self._command(), stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                          stderr=subprocess.DEVNULL, creationflags=flags)
        except (OSError, ValueError) as exc:
            self._proc = None
            self.failed.emit(f"Could not start the Windows speech engine: {exc}")
            return False
        threading.Thread(target=self._reader, args=(self._proc,), daemon=True).start()
        self._send(f"R:{int(self.rate)}")
        if self.voice.strip():
            self._send(f"V:{self.voice.strip()}")
        return True

    def _reader(self, proc: subprocess.Popen) -> None:
        assert proc.stdout is not None
        for raw in proc.stdout:
            token = raw.strip()
            if token == b"READY":
                self.ready.emit(True)
            elif token == b"DONE" and proc is self._proc:
                with self._lock:
                    self._pending = max(0, self._pending - 1)
                    idle = self._pending == 0
                if idle:
                    self.speaking_changed.emit(False)
        if proc is self._proc and self._pending:
            with self._lock:
                self._pending = 0
            self.speaking_changed.emit(False)

    def warmup(self) -> None:
        if self.available():
            self._ensure()

    def say(self, text: str) -> bool:
        text = speakable(text)
        if not self.enabled or len(text) < 2 or not self.available() or not self._ensure():
            return False
        for chunk in re.findall(r".{1,420}(?:\s+|$)", text):
            chunk = chunk.strip()
            if not chunk:
                continue
            with self._lock:
                self._pending += 1
                first = self._pending == 1
            if first:
                self.speaking_changed.emit(True)
            if not self._send("S:" + chunk):
                with self._lock:
                    self._pending = max(0, self._pending - 1)
                self.failed.emit("The speech engine stopped responding.")
                return False
        return True

    def stop(self) -> None:
        proc, self._proc = self._proc, None
        was = self._pending > 0
        with self._lock:
            self._pending = 0
        if proc is not None and proc.poll() is None:
            try:
                proc.kill()
            except OSError:
                pass
        if was:
            self.speaking_changed.emit(False)

    def shutdown(self) -> None:
        self.enabled = False
        self.stop()
