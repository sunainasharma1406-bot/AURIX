"""AURIX v6 layout: the neural core fills the window; glass panels float on top of it."""
from __future__ import annotations

from PySide6.QtGui import QPalette
from PySide6.QtWidgets import QButtonGroup, QProgressBar, QStackedWidget

from .blob import HoloCore
from .common import *  # noqa: F401,F403
from .dialogs import Composer
from .proactive import aqi_label, wmo

KIND_COLOR = {"briefing": "#5ef0ff", "weather": "#ffd666", "news": "#ff8c6e", "health": "#6eff96", "wellness": "#ff78be", "system": "#8b9db0"}


class ElideLabel(QLabel):
    """Single-line label that elides long text (model ids, paths) instead of growing the layout."""

    def __init__(self, text: str = "") -> None:
        super().__init__()
        self._full = text
        self.setMinimumWidth(10)
        self.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Preferred)

    def setText(self, text: str) -> None:  # noqa: N802
        self._full = text
        self.setToolTip(text)
        self.update()

    def text(self) -> str:
        return self._full

    def paintEvent(self, event) -> None:  # noqa: N802
        del event
        p = QPainter(self)
        p.setPen(self.palette().color(QPalette.WindowText))
        p.setFont(self.font())
        p.drawText(self.rect(), int(self.alignment()) | Qt.AlignVCenter, self.fontMetrics().elidedText(self._full, Qt.ElideRight, self.width()))
        p.end()


class UiMixin:
    def _glass(self, name: str, width: int | None = None) -> QFrame:
        f = QFrame()
        f.setObjectName(name)
        if width:
            f.setFixedWidth(width)
        return f

    def _compact_row(self, layout: QVBoxLayout, title: str, value: str) -> tuple[QWidget, ElideLabel, QLabel]:
        row = QWidget()
        h = QHBoxLayout(row)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(8)
        t = QLabel(title)
        t.setObjectName("mutedNote")
        v = ElideLabel(value)
        v.setObjectName("pairValue")
        v.setAlignment(Qt.AlignRight)
        sub = QLabel("")  # detail line kept for the logic layer; shown as tooltip instead
        sub.setParent(row)
        sub.hide()
        h.addWidget(t)
        h.addWidget(v, 1)
        layout.addWidget(row)
        return row, v, sub

    def _make_pair(self, layout: QVBoxLayout, title: str, value: str) -> ElideLabel:
        return self._compact_row(layout, title, value)[1]

    def _make_strip_item(self, title: str, value: str) -> tuple[QFrame, QLabel]:
        frame = QFrame()
        frame.setObjectName("stripCell")
        h = QHBoxLayout(frame)
        h.setContentsMargins(10, 5, 10, 5)
        h.setSpacing(6)
        t, v = QLabel(title), QLabel(value)
        t.setObjectName("microLabel")
        v.setObjectName("stripValue")
        h.addWidget(t)
        h.addWidget(v)
        return frame, v

    def _bar_row(self, layout: QVBoxLayout, label: str) -> tuple[QProgressBar, QLabel]:
        row = QHBoxLayout()
        row.setSpacing(8)
        lab = QLabel(label)
        lab.setObjectName("microLabel")
        lab.setFixedWidth(34)
        bar = QProgressBar()
        bar.setRange(0, 100)
        bar.setTextVisible(False)
        bar.setFixedHeight(5)
        val = QLabel("—")
        val.setObjectName("pairValue")
        val.setFixedWidth(38)
        val.setAlignment(Qt.AlignRight)
        row.addWidget(lab)
        row.addWidget(bar, 1)
        row.addWidget(val)
        layout.addLayout(row)
        return bar, val

    def _build_ui(self) -> None:
        self.core = HoloCore()
        self.core.setObjectName("root")
        self.core.set_insets(14 + 236 + 14, 14 + 430 + 14, 300)
        outer = QHBoxLayout(self.core)
        outer.setContentsMargins(14, 14, 14, 14)
        outer.setSpacing(14)

        # ---------- left glass rail ----------
        sidebar = self._glass("sidebar", 236)
        side = QVBoxLayout(sidebar)
        side.setContentsMargins(14, 16, 14, 14)
        side.setSpacing(8)
        logo_row = QHBoxLayout()
        logo = QLabel("A")
        logo.setObjectName("logoMark")
        logo.setFixedSize(38, 38)
        logo.setAlignment(Qt.AlignCenter)
        col = QVBoxLayout()
        col.setSpacing(0)
        brand = QLabel("AURIX")
        brand.setObjectName("brand")
        ver = QLabel(f"INTELLIGENCE · v{APP_VERSION}")
        ver.setObjectName("microLabel")
        col.addWidget(brand)
        col.addWidget(ver)
        logo_row.addWidget(logo)
        logo_row.addLayout(col, 1)
        side.addLayout(logo_row)
        self.new_btn = QPushButton("＋  New session")
        self.new_btn.setObjectName("navPrimary")
        self.new_btn.clicked.connect(self._new_conversation)
        side.addSpacing(4)
        side.addWidget(self.new_btn)
        rl = QLabel("RECENT SESSIONS")
        rl.setObjectName("sectionLabel")
        side.addWidget(rl)
        self.sessions = QListWidget()
        self.sessions.setObjectName("sessionList")
        self.sessions.setMinimumHeight(70)
        self.sessions.itemClicked.connect(self._select_session)
        self.sessions.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        side.addWidget(self.sessions, 1)

        stats = QFrame()
        stats.setObjectName("statsCard")
        sl = QVBoxLayout(stats)
        sl.setContentsMargins(12, 9, 12, 9)
        sl.setSpacing(4)
        st = QLabel("SYSTEMS")
        st.setObjectName("sectionLabel")
        sl.addWidget(st)
        self.server_card = self._compact_row(sl, "Engine", "DISCOVERING…")
        self.model_card = self._compact_row(sl, "Model", "Not detected")
        self.perception_card = self._compact_row(sl, "Vision", "NOT DETECTED")
        self.voice_card = self._compact_row(sl, "Voice in", "NOT INITIALIZED")
        self.internet_value = self._make_pair(sl, "Internet", "CHECKING")
        self.cloud_value = self._make_pair(sl, "Cloud fallback", "DISABLED")
        self.memory_value = self._make_pair(sl, "Local messages", str(self.memory.message_count()))
        self.saved_memory_value = self._make_pair(sl, "Saved memories", str(len(self.memory.list_memories())))
        self.accel_value = self._make_pair(sl, "GPU accelerator", "Not verified")
        side.addWidget(stats)

        ah = QHBoxLayout()
        al = QLabel("ACTIVITY")
        al.setObjectName("sectionLabel")
        ah.addWidget(al, 1)
        sync = QPushButton("↻ SYNC")
        sync.setObjectName("smallButton")
        sync.clicked.connect(lambda: self.refresh_diagnostics())
        ah.addWidget(sync)
        side.addLayout(ah)
        self.activity = QListWidget()
        self.activity.setObjectName("activityList")
        self.activity.setMaximumHeight(72)
        self.activity.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        side.addWidget(self.activity)
        self.memory_btn = QPushButton("◫   Memory vault")
        self.memory_btn.clicked.connect(self._open_memory)
        self.settings_btn = QPushButton("⚙   Configuration")
        self.settings_btn.clicked.connect(self._open_settings)
        self.assistant_btn = QPushButton("✦   Assistant")
        self.assistant_btn.clicked.connect(self._open_assistant_settings)
        self.update_btn = QPushButton("↻   Update manager")
        self.update_btn.clicked.connect(self._check_updates)
        self.quit_btn = QPushButton("⏻   Quit AURIX")
        self.quit_btn.clicked.connect(self._quit_app)
        for b in (self.memory_btn, self.settings_btn, self.assistant_btn, self.update_btn, self.quit_btn):
            b.setObjectName("railButton")
            side.addWidget(b)
        outer.addWidget(sidebar)

        # ---------- centre: status, greeting, live deck ----------
        centre = QVBoxLayout()
        centre.setSpacing(10)
        top = QHBoxLayout()
        top.setSpacing(8)
        eyebrow = QLabel("AURIX  ·  COMMAND CORE")
        eyebrow.setObjectName("sectionLabel")
        top.addWidget(eyebrow)
        top.addStretch(1)
        self.local_strip = self._make_strip_item("ENGINE", "CHECKING")
        self.net_strip = self._make_strip_item("INTERNET", "CHECKING")
        self.cloud_strip = self._make_strip_item("CLOUD", "DISABLED")
        for s in (self.local_strip, self.net_strip, self.cloud_strip):
            top.addWidget(s[0])
        self.pulse_dot = QLabel("●")
        self.pulse_dot.setObjectName("pulseDot")
        top.addWidget(self.pulse_dot)
        self.header_status = QLabel("LOCAL CORE · CHECKING")
        self.header_status.setObjectName("statusPill")
        top.addWidget(self.header_status)
        centre.addLayout(top)
        centre.addStretch(1)
        self.hero_title = QLabel("Welcome.")
        self.hero_title.setObjectName("heroTitle")
        self.hero_title.setAlignment(Qt.AlignCenter)
        self.hero_sub = QLabel("")
        self.hero_sub.setObjectName("mutedNote")
        self.hero_sub.setAlignment(Qt.AlignCenter)
        centre.addWidget(self.hero_title)
        centre.addWidget(self.hero_sub)
        brow = QHBoxLayout()
        brow.addStretch(1)
        self.brief_btn = QPushButton("▶  BRIEF ME")
        self.brief_btn.setObjectName("pillButton")
        self.brief_btn.clicked.connect(self._brief_now)
        self.proactive_check = QCheckBox("Proactive mode")
        self.proactive_check.setChecked(bool(self.settings.get("proactive_enabled", True)))
        self.proactive_check.toggled.connect(self._toggle_proactive)
        brow.addWidget(self.brief_btn)
        brow.addSpacing(14)
        brow.addWidget(self.proactive_check)
        brow.addStretch(1)
        centre.addLayout(brow)
        centre.addSpacing(4)

        deck = QHBoxLayout()
        deck.setSpacing(10)
        # weather
        wx = self._glass("deckCard")
        wx.setFixedHeight(152)
        wl = QVBoxLayout(wx)
        wl.setContentsMargins(14, 10, 14, 10)
        wl.setSpacing(2)
        wh = QHBoxLayout()
        wt = QLabel("WEATHER")
        wt.setObjectName("sectionLabel")
        self.wx_place = QLabel("—")
        self.wx_place.setObjectName("microLabel")
        wh.addWidget(wt)
        wh.addStretch(1)
        wh.addWidget(self.wx_place)
        wl.addLayout(wh)
        self.wx_temp = QLabel("--°")
        self.wx_temp.setObjectName("bigTemp")
        self.wx_cond = QLabel("Waiting for weather…")
        self.wx_cond.setObjectName("metricValue")
        self.wx_detail = QLabel("")
        self.wx_detail.setObjectName("metricSub")
        self.wx_detail.setWordWrap(True)
        wl.addWidget(self.wx_temp)
        wl.addWidget(self.wx_cond)
        wl.addWidget(self.wx_detail)
        wl.addStretch(1)
        # health
        hl = self._glass("deckCard")
        hl.setFixedHeight(152)
        hv = QVBoxLayout(hl)
        hv.setContentsMargins(14, 10, 14, 10)
        hv.setSpacing(5)
        ht = QLabel("SYSTEM HEALTH")
        ht.setObjectName("sectionLabel")
        hv.addWidget(ht)
        self.hl_bars = {k: self._bar_row(hv, lab) for k, lab in (("cpu", "CPU"), ("ram", "RAM"), ("disk", "DISK"), ("battery", "BATT"))}
        self.hl_note = QLabel("")
        self.hl_note.setObjectName("metricSub")
        self.hl_note.setWordWrap(True)
        hv.addWidget(self.hl_note)
        hv.addStretch(1)
        # news
        nw = self._glass("deckCard")
        nw.setFixedHeight(152)
        nv = QVBoxLayout(nw)
        nv.setContentsMargins(14, 10, 14, 10)
        nv.setSpacing(4)
        nh = QHBoxLayout()
        nt = QLabel("NEWS · LIVE")
        nt.setObjectName("sectionLabel")
        self.news_meta = QLabel("")
        self.news_meta.setObjectName("microLabel")
        nh.addWidget(nt)
        nh.addStretch(1)
        nh.addWidget(self.news_meta)
        nv.addLayout(nh)
        self.news_label = QLabel("Fetching headlines…")
        self.news_label.setObjectName("newsLabel")
        self.news_label.setTextFormat(Qt.RichText)
        self.news_label.setWordWrap(True)
        self.news_label.setAlignment(Qt.AlignTop | Qt.AlignLeft)
        self.news_label.linkActivated.connect(self._open_news_link)
        nv.addWidget(self.news_label, 1)
        for card in (wx, hl, nw):
            deck.addWidget(card, 1)
        centre.addLayout(deck)
        outer.addLayout(centre, 1)

        # ---------- right glass chat panel (CHAT / FEED) ----------
        panel = self._glass("chatPanel", 430)
        pl = QVBoxLayout(panel)
        pl.setContentsMargins(16, 14, 16, 12)
        pl.setSpacing(10)
        ph = QHBoxLayout()
        ph.setSpacing(6)
        self.tab_chat = QPushButton("CHAT")
        self.tab_feed = QPushButton("FEED")
        grp = QButtonGroup(self)
        for i, b in enumerate((self.tab_chat, self.tab_feed)):
            b.setObjectName("tabButton")
            b.setCheckable(True)
            grp.addButton(b, i)
            ph.addWidget(b)
        self.tab_chat.setChecked(True)
        ph.addStretch(1)
        open_ui = QPushButton("RUNTIME UI ↗")
        open_ui.setObjectName("smallButton")
        open_ui.clicked.connect(self._open_runtime_ui)
        ph.addWidget(open_ui)
        pl.addLayout(ph)
        self.stack = QStackedWidget()
        grp.idClicked.connect(self._on_tab)

        page_chat = QWidget()
        cl = QVBoxLayout(page_chat)
        cl.setContentsMargins(0, 0, 0, 0)
        cl.setSpacing(10)
        self.chat_view = QTextBrowser()
        self.chat_view.setObjectName("chatView")
        self.chat_view.setOpenLinks(False)
        self.chat_view.setReadOnly(True)
        self.chat_view.anchorClicked.connect(self._on_chat_link)
        self.chat_view.viewport().setAutoFillBackground(False)
        cl.addWidget(self.chat_view, 1)
        grid = QGridLayout()
        grid.setSpacing(6)
        for n, (attr, label, slot) in enumerate([("web_btn", "⌕  Web", self._ask_web_search), ("screen_btn", "▣  Screen", self._capture_screen),
                                                  ("image_btn", "▧  Image", self._choose_image), ("plan_btn", "◇  Plan", self._plan_action),
                                                  ("voice_btn", "◉  Voice", self._start_voice_input)]):
            b = QPushButton(label)
            b.setObjectName("toolButton")
            b.clicked.connect(slot)
            setattr(self, attr, b)
            grid.addWidget(b, n // 3, n % 3)
        self.wake_btn = QPushButton("◎  Wake off")
        self.wake_btn.setObjectName("toolButton")
        self.wake_btn.setCheckable(True)
        self.wake_btn.toggled.connect(self._toggle_wake_word)
        grid.addWidget(self.wake_btn, 1, 2)
        cl.addLayout(grid)
        cf = QFrame()
        cf.setObjectName("composerFrame")
        cfl = QVBoxLayout(cf)
        cfl.setContentsMargins(12, 10, 12, 10)
        cfl.setSpacing(8)
        self.composer = Composer()
        self.composer.setObjectName("composer")
        self.composer.setPlaceholderText("Message AURIX…   (Ctrl + Enter)   ·   start with “search” for the web")
        self.composer.setFixedHeight(66)
        self.composer.send_requested.connect(self._send_message)
        cfl.addWidget(self.composer)
        bot = QHBoxLayout()
        self.speak_check = QCheckBox("Speak replies")
        self.speak_check.setChecked(bool(self.settings.get("speak_replies", True)))
        self.speak_check.setToolTip("Live voice: AURIX speaks each sentence while it is still writing.")
        self.speak_check.toggled.connect(self._set_speak_replies)
        self.test_voice_btn = QPushButton("🔊")
        self.test_voice_btn.setObjectName("smallButton")
        self.test_voice_btn.setToolTip("Test the voice output")
        self.test_voice_btn.clicked.connect(self._test_voice)
        self.send_btn = QPushButton("SEND  ↗")
        self.send_btn.setObjectName("transmitButton")
        self.send_btn.clicked.connect(self._send_message)
        bot.addWidget(self.speak_check)
        bot.addWidget(self.test_voice_btn)
        bot.addStretch(1)
        bot.addWidget(self.send_btn)
        cfl.addLayout(bot)
        cl.addWidget(cf)
        hint = QLabel("LOCAL FIRST · WEB ONLY WHEN YOU SEARCH · ACTIONS NEED APPROVAL")
        hint.setObjectName("footerNote")
        hint.setAlignment(Qt.AlignCenter)
        cl.addWidget(hint)

        self.feed_view = QTextBrowser()
        self.feed_view.setObjectName("chatView")
        self.feed_view.setOpenLinks(False)
        self.feed_view.viewport().setAutoFillBackground(False)
        self.stack.addWidget(page_chat)
        self.stack.addWidget(self.feed_view)
        pl.addWidget(self.stack, 1)
        outer.addWidget(panel)

        self.sessions.setContextMenuPolicy(Qt.CustomContextMenu)
        self.sessions.customContextMenuRequested.connect(self._session_menu)
        QShortcut(QKeySequence("Ctrl+N"), self, activated=self._new_conversation)
        QShortcut(QKeySequence("Ctrl+K"), self, activated=self._ask_web_search)
        self.setCentralWidget(self.core)
        self._apply_style()

    # ---------- feed + hero + deck updates ----------
    def _on_tab(self, index: int) -> None:
        self.stack.setCurrentIndex(index)
        if index == 1:
            self.unread = 0
            self.tab_feed.setText("FEED")
            self._render_feed()

    def _render_feed(self) -> None:
        parts = ["<html><body style='background:transparent;color:#d9f2f8;font-family:Segoe UI,Arial,sans-serif;font-size:10pt;'>"]
        if not self.feed:
            parts.append("<div style='color:#f2fcff;font-size:15pt;margin:10px 2px 4px;'>Nothing yet.</div>"
                         "<div style='color:#7f9fb1;'>Briefings, weather, news and health alerts appear here as AURIX notices them.</div>")
        for ev in self.feed:
            c = KIND_COLOR.get(ev["kind"], "#8b9db0")
            parts.append(f"<table width='100%' cellspacing='0' cellpadding='0' style='margin:8px 0;'><tr><td width='3' bgcolor='{c}'></td>"
                         "<td bgcolor='#0b1522' style='padding:10px 13px;'>"
                         f"<span style='color:{c};font-size:7pt;font-weight:800;letter-spacing:1.4px;'>{html.escape(ev['kind'].upper())} · {ev['time']}</span><br>"
                         f"<span style='color:#ffffff;font-weight:600;'>{html.escape(ev['title'])}</span><br>"
                         f"<span style='color:#bcd3dc;'>{html.escape(ev['text'])}</span></td></tr></table>")
        parts.append("</body></html>")
        self.feed_view.setHtml("".join(parts))

    def _refresh_hero(self) -> None:
        now = datetime.now()
        name = str(self.settings.get("user_name", "")).strip()
        part = "morning" if now.hour < 12 else "afternoon" if now.hour < 17 else "evening"
        self.hero_title.setText(f"Good {part}" + (f", {name}." if name else "."))
        sub = now.strftime("%A, %d %B   ·   %I:%M %p")
        wx = self.proactive.wx if hasattr(self, "proactive") else None
        if wx:
            sub += f"   ·   {wx['place']} {wx['temp']:.0f}° {wmo(wx['code'])[0].lower()}"
        self.hero_sub.setText(sub)

    def _on_weather(self, d: dict) -> None:
        cond, icon = wmo(d["code"])
        self.wx_place.setText(d["place"].upper())
        self.wx_temp.setText(f"{icon}  {d['temp']:.0f}°")
        self.wx_cond.setText(cond)
        aqi = f" · AQI {int(d['aqi'])} ({aqi_label(d['aqi'])})" if d.get("aqi") is not None else ""
        self.wx_detail.setText(f"Feels {d['feels']:.0f}° · Humidity {d['humidity']:.0f}% · Wind {d['wind']:.0f} km/h\n"
                               f"High {d['hi']:.0f}° / Low {d['lo']:.0f}° · Rain {int(d['rain'])}%{aqi}")
        self.core.set_available("weather", True)
        self.core.fire("weather", True)
        self._refresh_hero()

    def _on_health(self, h: dict) -> None:
        for key, (bar, val) in self.hl_bars.items():
            v = h.get(key)
            bar.setValue(int(v) if v is not None else 0)
            val.setText(f"{v:.0f}%" if v is not None else "—")
        mins = (time.time() - self.proactive.started) / 60
        every = max(20, int(self.settings.get("break_minutes", 50)))
        left = max(0, every - int(mins) % every)
        plug = "" if h.get("battery") is None else (" · charging" if h.get("plugged") else " · on battery")
        self.hl_note.setText(f"On screen {int(mins)} min · break in {left} min{plug}")

    def _on_news(self, items: list) -> None:
        rows = []
        for it in items[:3]:
            url = safe_http_url(it["url"]) or ""
            title = html.escape(it["title"][:74] + ("…" if len(it["title"]) > 74 else ""))
            src = html.escape(it["source"] or it["cat"])
            rows.append(f"<a href='{html.escape(url, quote=True)}' style='color:#e6f7fc;text-decoration:none;'>• {title}</a> <span style='color:#6f8fa2;'>{src}</span>")
        self.news_label.setText("<br>".join(rows) or "No headlines.")
        self.news_meta.setText(f"{len(items)} · {datetime.now().strftime('%I:%M %p').lstrip('0')}")
        self.core.set_available("news", True)
        self.core.fire("news", True)

    def _open_news_link(self, url: str) -> None:
        safe = safe_http_url(url)
        if safe:
            QDesktopServices.openUrl(QUrl(safe))

    def _apply_style(self) -> None:
        self.setStyleSheet("""
            QMainWindow, QWidget#root { background: #04070d; color: #e8f6ff; font-family: 'Segoe UI'; font-size: 9pt; }
            QLabel { background: transparent; }
            #sidebar, #chatPanel { background: rgba(6,11,20,0.84); border: 1px solid #15293b; border-radius: 20px; }
            #deckCard { background: rgba(7,16,28,0.74); border: 1px solid #1b3a50; border-radius: 16px; }
            #logoMark { color: #04121a; font-size: 18pt; font-weight: 900; border-radius: 11px;
                background: qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 #5ef0ff,stop:1 #8b7bff); }
            #brand { color: #f0fbff; font-size: 17pt; font-weight: 800; letter-spacing: 4px; }
            #heroTitle { color: #f4fcff; font-size: 26pt; font-weight: 600; }
            #bigTemp { color: #ffffff; font-size: 22pt; font-weight: 300; }
            #sectionLabel { color: #5ef0ff; font-size: 7pt; font-weight: 800; letter-spacing: 1.6px; }
            #microLabel { color: #6f8da1; font-size: 6.6pt; font-weight: 700; letter-spacing: 1px; }
            #mutedNote { color: #8aa4b6; font-size: 8pt; }
            #footerNote { color: #50707f; font-size: 6.2pt; letter-spacing: .7px; }
            #newsLabel { color: #cfe6ee; font-size: 8.4pt; }
            QPushButton { background: rgba(94,240,255,0.06); border: 1px solid #1c3447; color: #bfe6f0; border-radius: 10px; padding: 8px 11px; font-size: 8pt; font-weight: 650; }
            QPushButton:hover { background: rgba(94,240,255,0.14); border-color: #5ef0ff; color: #ffffff; }
            QPushButton:pressed { background: rgba(94,240,255,0.25); }
            QPushButton:disabled { color: #4f6573; background: #0a121c; border-color: #14212d; }
            #navPrimary { background: qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #0b6f8a,stop:1 #5b4fd6); border: none; color: #fff; padding: 10px; font-weight: 750; }
            #navPrimary:hover { background: qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #0f8caa,stop:1 #7468f0); }
            #railButton { text-align: left; background: transparent; border: 1px solid transparent; padding: 7px 10px; }
            #railButton:hover { background: rgba(94,240,255,0.08); border-color: #1c3447; }
            #pillButton { border-radius: 15px; padding: 8px 20px; background: rgba(94,240,255,0.10); border-color: #2a7f93; color: #dffbff; letter-spacing: 1.2px; }
            #tabButton { border-radius: 9px; padding: 6px 16px; font-size: 7.4pt; letter-spacing: 1.4px; background: transparent; }
            #tabButton:checked { background: rgba(94,240,255,0.16); border-color: #5ef0ff; color: #ffffff; }
            #transmitButton { background: qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #12b4d0,stop:1 #7c6cf5); border: none; color: #fff; padding: 9px 22px; font-weight: 800; letter-spacing: .6px; }
            #transmitButton:hover { background: qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #3fd2ea,stop:1 #9588ff); }
            #transmitButton[stop="true"] { background: qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #b03a5c,stop:1 #7a2640); }
            #toolButton { padding: 8px 6px; font-size: 7.6pt; }
            #toolButton:checked { background: rgba(94,240,255,0.22); border-color: #5ef0ff; color: #fff; }
            #smallButton { padding: 5px 9px; font-size: 6.8pt; border-radius: 8px; }
            #statusPill { background: rgba(80,228,194,0.12); color: #9ff5e0; border: 1px solid #1f6b5e; border-radius: 12px; padding: 6px 12px; font-size: 6.8pt; font-weight: 800; letter-spacing: .6px; }
            #stripCell { background: rgba(8,16,28,0.72); border: 1px solid #1a2f42; border-radius: 12px; }
            #stripValue { color: #d3f7ff; font-size: 7.4pt; font-weight: 800; }
            #metricValue { color: #eefcff; font-size: 9.5pt; font-weight: 700; }
            #metricSub { color: #7f9fb1; font-size: 7.2pt; }
            #statsCard, #composerFrame { background: rgba(10,18,32,0.80); border: 1px solid #172a3b; border-radius: 14px; }
            #pairValue { color: #b8edf7; font-size: 7.5pt; font-weight: 800; }
            QProgressBar { background: #0d1a28; border: none; border-radius: 2px; }
            QProgressBar::chunk { border-radius: 2px; background: qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #5ef0ff,stop:1 #8b7bff); }
            #chatView { background: transparent; border: none; selection-background-color: #176782; }
            #composer { background: transparent; border: none; color: #effaff; selection-background-color: #17657d; font-size: 10pt; }
            #sessionList, #activityList { background: transparent; border: none; outline: none; color: #a9c2cf; }
            #sessionList::item { padding: 8px 10px; border-radius: 9px; margin: 1px 0; }
            #sessionList::item:selected { background: rgba(94,240,255,0.12); color: #eaffff; border-left: 2px solid #5ef0ff; }
            #sessionList::item:hover, #activityList::item:hover { background: rgba(94,240,255,0.07); }
            #activityList::item { color: #7f9bac; font-size: 7pt; padding: 2px 4px; }
            #pulseDot { color: #50e4c2; font-size: 10pt; }
            #dialogEyebrow { color: #66d0e6; font-size: 8pt; font-weight: 850; letter-spacing: 1.2px; }
            QDialog, QMessageBox { background: #070d17; color: #e8f6ff; }
            QLineEdit, QSpinBox { background: #081827; border: 1px solid #244c62; border-radius: 8px; padding: 8px; color: #e9faff; }
            QCheckBox { color: #a9c6d3; spacing: 8px; font-size: 8pt; }
            QScrollBar:vertical { background: transparent; width: 8px; margin: 2px; }
            QScrollBar::handle:vertical { background: #1f4a5e; border-radius: 4px; min-height: 24px; }
            QScrollBar::handle:vertical:hover { background: #3aa5c0; }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
            QMenu { background: #0a1220; color: #d8f3fb; border: 1px solid #1c3447; padding: 4px; }
            QMenu::item { padding: 7px 18px; border-radius: 6px; }
            QMenu::item:selected { background: rgba(94,240,255,0.16); }
            QToolTip { background: #102a3b; color: #e7faff; border: 1px solid #3e8ba2; padding: 5px; }
        """)

    def _on_chat_link_dispatch(self, action: str) -> None:  # used by tiles
        {"think": self.composer.setFocus, "perceive": self._capture_screen, "research": self._ask_web_search, "act": self._plan_action}.get(action, lambda: None)()
