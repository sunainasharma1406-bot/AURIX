"""AURIX v6 visual core: a neural network wrapped into a living blob, plus the floating orb."""
from __future__ import annotations

import math
import random

from PySide6.QtCore import QPoint, QPointF, QRectF, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QFont, QPainter, QPainterPath, QPen, QRadialGradient
from PySide6.QtWidgets import QApplication, QLabel, QVBoxLayout, QWidget

CYAN = (94, 240, 255)
GREY = (130, 150, 168)
FEATURES = [
    ("chat", "CHAT", (139, 123, 255)), ("web", "WEB", (94, 240, 255)), ("memory", "MEMORY", (80, 228, 194)),
    ("vision", "VISION", (255, 191, 122)), ("voice", "VOICE", (255, 120, 190)), ("action", "ACTION", (120, 170, 255)),
    ("weather", "WEATHER", (255, 214, 102)), ("news", "NEWS", (255, 140, 110)), ("health", "HEALTH", (110, 255, 150)),
]
KEYS = [f[0] for f in FEATURES]


def _lerp(a, b, t):
    return (int(a[0] + (b[0] - a[0]) * t), int(a[1] + (b[1] - a[1]) * t), int(a[2] + (b[2] - a[2]) * t))


class NeuralBlob:
    """Neurons on a morphing sphere, wired to their neighbours; signals ripple along the wires and
    feature satellites orbit the blob, tethered to the core."""

    def __init__(self, n: int = 150, sats: bool = True, seed: int = 3) -> None:
        self.rnd = random.Random(seed)
        self.n, self.sats = n, sats
        ga = math.pi * (3 - math.sqrt(5))
        self.pts = []
        for i in range(n):
            y = 1 - 2 * (i + 0.5) / n
            r = math.sqrt(1 - y * y)
            self.pts.append((math.cos(ga * i) * r, y, math.sin(ga * i) * r))
        self.ang = [(math.acos(y), math.atan2(z, x)) for x, y, z in self.pts]
        edges, self.adj = set(), [[] for _ in range(n)]
        for i, (x, y, z) in enumerate(self.pts):
            near = sorted(((x - a) ** 2 + (y - b) ** 2 + (z - c) ** 2, j) for j, (a, b, c) in enumerate(self.pts) if j != i)[:3]
            for _, j in near:
                e = (min(i, j), max(i, j))
                if e not in edges:
                    edges.add(e)
                    self.adj[i].append(j)
                    self.adj[j].append(i)
        self.edges = sorted(edges)
        self.hop_cache: dict[int, list[int]] = {}
        self.t = 0.0
        self.frame = 0
        self.energy = self.kick = self.speak = 0.0
        self.thinking = self.speaking = self.online = False
        self.busy: str | None = None
        self.rot_y, self.rot_x = 0.0, 0.3
        self.act = [0.0] * n
        self.act_col = [CYAN] * n
        self.waves: list[dict] = []
        self.beams: list[dict] = []
        self.sat_glow = {k: 0.0 for k in KEYS}
        self.avail = {k: True for k in KEYS}
        self.sat_ph = [2 * math.pi * i / len(KEYS) for i in range(len(KEYS))]
        self.sat3: dict[str, tuple] = {}
        self.sat_pos: dict[str, tuple] = {}
        self.n3: list[tuple] = []
        self.proj: list[tuple] = []
        self.dust = [(self.rnd.random() * 6.28, 1.25 + self.rnd.random() * 1.1, (self.rnd.random() - 0.5) * 0.5,
                      (self.rnd.random() - 0.5) * 1.2, 0.6 + self.rnd.random() * 1.2) for _ in range(60 if sats else 0)]

    # ---- graph helpers
    def hops(self, seed: int) -> list[int]:
        h = self.hop_cache.get(seed)
        if h is None:
            h = [99] * self.n
            h[seed] = 0
            queue = [seed]
            for u in queue:
                for v in self.adj[u]:
                    if h[v] == 99:
                        h[v] = h[u] + 1
                        queue.append(v)
            self.hop_cache[seed] = h
        return h

    def wave(self, seed: int, col, strength: float = 1.0, speed: float = 0.07) -> None:
        if len(self.waves) > 10:
            self.waves.pop(0)
        h = self.hops(seed)
        self.waves.append({"h": h, "t0": self.t, "col": col, "s": strength, "sp": speed,
                           "max": (max(x for x in h if x < 99) + 3) * speed})

    def _seed_for(self, key: str) -> int:
        v = self.sat3.get(key)
        if not v or not self.n3:
            return self.rnd.randrange(self.n)
        ln = math.sqrt(v[0] ** 2 + v[1] ** 2 + v[2] ** 2) or 1.0
        v = (v[0] / ln, v[1] / ln, v[2] / ln)
        return max(range(self.n), key=lambda i: self.n3[i][0] * v[0] + self.n3[i][1] * v[1] + self.n3[i][2] * v[2])

    def fire(self, key: str, inbound: bool = False) -> None:
        if key not in KEYS:
            return
        col = FEATURES[KEYS.index(key)][2]
        seed = self._seed_for(key)
        if not self.sats:
            self.wave(seed, col)
            return
        if len(self.beams) < 14:
            self.beams.append({"key": key, "t0": self.t, "dur": 1.25, "in": inbound, "seed": seed, "col": col, "w": False, "a": False})

    def step(self, dt: float) -> None:
        self.frame += 1
        self.t += dt * (1 + 1.6 * self.energy)
        self.kick *= 0.95
        self.energy += ((1.0 if self.thinking else self.kick) - self.energy) * 0.07
        self.speak += ((1.0 if self.speaking else 0.0) - self.speak) * 0.12
        if self.busy and self.frame % 11 == 0:
            self.fire(self.busy, inbound=(self.frame // 11) % 2 == 0)
        if self.thinking and self.frame % 13 == 0:
            self.wave(self.rnd.randrange(self.n), (139, 123, 255), 0.9)
        if self.speaking and self.frame % 9 == 0:
            self.wave(self.rnd.randrange(self.n), (255, 120, 190), 0.8, 0.05)
        if self.frame % 42 == 0:
            self.wave(self.rnd.randrange(self.n), CYAN if self.online else GREY, 0.45)
        keep = []
        for b in self.beams:
            u = (self.t - b["t0"]) / b["dur"]
            if not b["w"] and u >= (0.7 if b["in"] else 0.25):
                b["w"] = True
                self.wave(b["seed"], b["col"])
            if not b["a"] and u >= (0.05 if b["in"] else 0.92):
                b["a"] = True
                self.sat_glow[b["key"]] = 1.0
            if u < 1.1:
                keep.append(b)
        self.beams = keep
        act, col, live = [0.0] * self.n, self.act_col, []
        for w in self.waves:
            age = self.t - w["t0"]
            if age > w["max"]:
                continue
            live.append(w)
            sp, s, c = w["sp"], w["s"], w["col"]
            for i, h in enumerate(w["h"]):
                x = age / sp - h
                if 0 <= x < 2.6:
                    v = (1 - x / 2.6) ** 1.6 * s
                    if v > act[i]:
                        act[i] = v
                        col[i] = c
        self.waves, self.act = live, act
        for k in self.sat_glow:
            self.sat_glow[k] *= 0.955

    # ---- painting
    def paint(self, p: QPainter, cx: float, cy: float, R: float, labels: bool = True) -> None:
        t, sin, cos = self.t, math.sin, math.cos
        env = 0.5 + 0.5 * sin(t * 9) * sin(t * 3.1 + 1)
        amp = 0.085 + 0.10 * self.energy + 0.07 * self.speak * env
        breathe = 1 + 0.025 * sin(t * 1.3) + 0.05 * self.speak * sin(t * 11)
        cyw, syw, cxw, sxw = cos(self.rot_y), sin(self.rot_y), cos(self.rot_x), sin(self.rot_x)
        base = CYAN if self.online else GREY
        proj, n3 = [], []
        for (ux, uy, uz), (th, ph) in zip(self.pts, self.ang):
            d = (1 + amp * sin(3 * th + t * 1.1) * cos(2 * ph - t * 0.8) + 0.035 * sin(7 * ph + t * 2 + th * 3)) * breathe
            x, y, z = ux * d, uy * d, uz * d
            x1 = x * cyw + z * syw
            z1 = -x * syw + z * cyw
            y2 = y * cxw - z1 * sxw
            z2 = y * sxw + z1 * cxw
            s = 3.4 / (3.4 - z2)
            proj.append((cx + x1 * R * s, cy + y2 * R * s, z2))
            n3.append((x1, y2, z2))
        self.proj, self.n3 = proj, n3
        sats = []
        if self.sats:
            ry = self.rot_y * 0.35
            for k, (key, name, col) in enumerate(FEATURES):
                th = self.sat_ph[k] + t * (0.20 if k % 2 == 0 else -0.16)
                rho, tilt = 1.55 + 0.08 * (k % 3), 0.30 + 0.16 * (k % 4)
                x, y0 = rho * cos(th), rho * sin(th)
                y, z = y0 * sin(tilt), y0 * cos(tilt)
                x1, z1 = x * cos(ry) + z * sin(ry), -x * sin(ry) + z * cos(ry)
                s = 3.4 / (3.4 - z1)
                self.sat3[key] = (x1, y, z1)
                self.sat_pos[key] = (cx + x1 * R * s, cy + y * R * s, z1)
                sats.append((key, name, col, self.sat_pos[key]))
            # dust
            p.setPen(Qt.NoPen)
            for a, rho, sp, yk, sz in self.dust:
                th = a + t * sp
                x, z = rho * cos(th), rho * sin(th)
                p.setBrush(QColor(base[0], base[1], base[2], 50 if z < 0 else 120))
                p.drawEllipse(QPointF(cx + x * R, cy + yk * R * 0.55 + z * R * 0.18), sz, sz)
        act, acol = self.act, self.act_col
        scale = max(0.55, R / 170)
        qb, qf, act_b, act_f = QPainterPath(), QPainterPath(), [], []
        for a, b in self.edges:
            pa, pb = proj[a], proj[b]
            front = pa[2] + pb[2] > 0
            ac = act[a] if act[a] > act[b] else act[b]
            if ac > 0.06:
                (act_f if front else act_b).append((a, b, ac))
                continue
            path = qf if front else qb
            path.moveTo(pa[0], pa[1])
            path.lineTo(pb[0], pb[1])

        def draw_active(lst, fa):
            for a, b, ac in lst:
                c = acol[a] if act[a] >= act[b] else acol[b]
                p.setPen(QPen(QColor(c[0], c[1], c[2], int((55 + 200 * ac) * fa)), (0.9 + 2.2 * ac) * scale))
                p.drawLine(QPointF(proj[a][0], proj[a][1]), QPointF(proj[b][0], proj[b][1]))

        def draw_nodes(front: bool):
            p.setPen(Qt.NoPen)
            order = sorted((i for i in range(self.n) if (proj[i][2] >= 0) == front), key=lambda i: proj[i][2])
            for i in order:
                x, y, z = proj[i]
                depth = (z + 1) / 2
                a_i = act[i]
                c = _lerp(base, acol[i], min(1.0, a_i * 1.4)) if a_i > 0.04 else base
                if a_i > 0.25:
                    p.setBrush(QColor(c[0], c[1], c[2], int(60 * a_i)))
                    p.drawEllipse(QPointF(x, y), (3 + 6 * a_i) * scale, (3 + 6 * a_i) * scale)
                r = (0.8 + 1.1 * depth + 2.2 * a_i) * scale
                p.setBrush(QColor(min(255, c[0] + 90), min(255, c[1] + 12), min(255, c[2]), int(60 + 130 * depth + 65 * a_i)))
                p.drawEllipse(QPointF(x, y), r, r)

        def draw_sats(front: bool):
            for key, name, col, (sx, sy, sz) in sats:
                if (sz >= 0) != front:
                    continue
                g = self.sat_glow[key]
                ok = self.avail[key]
                c = col if ok else (105, 120, 135)
                df = 1.0 if front else 0.55
                p.setPen(QPen(QColor(c[0], c[1], c[2], int((22 + 120 * g) * df)), 0.8 + 1.4 * g))
                p.drawLine(QPointF(cx, cy), QPointF(sx, sy))
                p.setPen(Qt.NoPen)
                if g > 0.05:
                    p.setBrush(QColor(c[0], c[1], c[2], int(g * 90)))
                    p.drawEllipse(QPointF(sx, sy), (6 + 9 * g) * scale, (6 + 9 * g) * scale)
                p.setBrush(QColor(c[0], c[1], c[2], int((150 + 105 * g) * df)))
                p.drawEllipse(QPointF(sx, sy), (3.6 + 2.6 * g) * scale, (3.6 + 2.6 * g) * scale)
                if labels:
                    p.setFont(self._font)
                    p.setPen(QColor(c[0], c[1], c[2], int(((200 if ok else 110) + 55 * g) * df)))
                    left = sx < cx - R * 0.2
                    tw = p.fontMetrics().horizontalAdvance(name)
                    p.drawText(QPointF(sx - 11 - tw if left else sx + 11, sy + 3), name)

        if self.sats:
            draw_sats(False)
        p.setPen(QPen(QColor(base[0], base[1], base[2], 34), 0.8 * scale))
        p.drawPath(qb)
        draw_active(act_b, 0.5)
        draw_nodes(False)
        pulse = 1 + 0.15 * sin(t * 3) + 0.35 * self.speak * env
        cr = R * 0.2 * pulse
        g = QRadialGradient(QPointF(cx, cy), cr)
        g.setColorAt(0, QColor(255, 255, 255, 255))
        g.setColorAt(0.28, QColor(base[0], base[1], base[2], 210))
        g.setColorAt(1, QColor(base[0], base[1], base[2], 0))
        p.setPen(Qt.NoPen)
        p.setBrush(g)
        p.drawEllipse(QPointF(cx, cy), cr, cr)
        p.setBrush(Qt.NoBrush)
        p.setPen(QPen(QColor(base[0], base[1], base[2], 125), 0.9 * scale))
        p.drawPath(qf)
        draw_active(act_f, 1.0)
        draw_nodes(True)
        # beams: core -> neuron -> satellite
        if self.sats:
            for b in self.beams:
                u = (self.t - b["t0"]) / b["dur"]
                if not 0 <= u <= 1 or b["key"] not in self.sat_pos:
                    continue
                n, s_ = proj[b["seed"]], self.sat_pos[b["key"]]
                pts = [(cx, cy), (n[0], n[1]), (s_[0], s_[1])]
                lens = [math.hypot(pts[1][0] - pts[0][0], pts[1][1] - pts[0][1]), math.hypot(pts[2][0] - pts[1][0], pts[2][1] - pts[1][1])]
                total = (lens[0] + lens[1]) or 1.0
                col = b["col"]
                p.setPen(QPen(QColor(col[0], col[1], col[2], int(150 * (1 - u * 0.6))), 1.6 * scale))
                p.drawLine(QPointF(*pts[0]), QPointF(*pts[1]))
                p.drawLine(QPointF(*pts[1]), QPointF(*pts[2]))
                p.setPen(Qt.NoPen)
                for tail in range(4):
                    f = (1 - u if b["in"] else u) + (tail * 0.035 if b["in"] else -tail * 0.035)
                    f = min(1.0, max(0.0, f)) * total
                    seg, off = (0, f) if f <= lens[0] else (1, f - lens[0])
                    ln = lens[seg] or 1.0
                    k = min(1.0, off / ln)
                    a, c2 = pts[seg], pts[seg + 1]
                    p.setBrush(QColor(col[0], col[1], col[2], 240 - tail * 55))
                    rr = (3.6 - tail * 0.6) * scale
                    p.drawEllipse(QPointF(a[0] + (c2[0] - a[0]) * k, a[1] + (c2[1] - a[1]) * k), rr, rr)
            draw_sats(True)

    _font = QFont("Segoe UI", 6, QFont.Bold)


class HoloCore(QWidget):
    """Full-window stage: the neural blob is the background of the whole app."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.blob = NeuralBlob(150, True, 3)
        self.blob._font.setLetterSpacing(QFont.AbsoluteSpacing, 1.2)
        self.setMinimumSize(1100, 700)
        rnd = random.Random(11)
        self.stars = [(rnd.random(), rnd.random(), rnd.random()) for _ in range(200)]
        self.left, self.right, self.bottom = 0, 0, 0
        self._drag = None
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._tick)
        self.timer.start(33)

    # public API (kept stable so the window code stays simple)
    def set_insets(self, left: int, right: int, bottom: int) -> None:
        self.left, self.right, self.bottom = left, right, bottom

    def set_online(self, online: bool) -> None:
        self.blob.online = online

    def set_thinking(self, v: bool) -> None:
        self.blob.thinking = v

    def set_speaking(self, v: bool) -> None:
        self.blob.speaking = v

    def pulse(self) -> None:
        self.blob.kick = 1.0

    def fire(self, key: str, inbound: bool = False) -> None:
        self.blob.fire(key, inbound)

    def set_busy(self, key: str | None) -> None:
        self.blob.busy = key

    def set_available(self, key: str, ok: bool) -> None:
        if key in self.blob.avail:
            self.blob.avail[key] = bool(ok)

    def showEvent(self, e) -> None:  # noqa: N802
        self.timer.start(33)
        super().showEvent(e)

    def hideEvent(self, e) -> None:  # noqa: N802
        self.timer.stop()
        super().hideEvent(e)

    def _tick(self) -> None:
        b = self.blob
        b.step(0.033)
        if self._drag is None:
            b.rot_y += 0.0045 + 0.010 * b.energy + 0.004 * b.speak
        self.update()

    def mousePressEvent(self, e) -> None:  # noqa: N802
        self._drag = e.position()

    def mouseMoveEvent(self, e) -> None:  # noqa: N802
        if self._drag is not None:
            d = e.position() - self._drag
            self._drag = e.position()
            self.blob.rot_y += d.x() * 0.01
            self.blob.rot_x = max(-1.1, min(1.1, self.blob.rot_x + d.y() * 0.01))

    def mouseReleaseEvent(self, e) -> None:  # noqa: N802
        self._drag = None

    def paintEvent(self, event) -> None:  # noqa: N802
        del event
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        cw = max(200, w - self.left - self.right)
        avail_h = max(240, h - self.bottom - 60)
        cx, cy = self.left + cw / 2, 60 + avail_h / 2
        R = max(60.0, min(cw * 0.235, avail_h * 0.34))
        b = self.blob
        base = CYAN if b.online else GREY
        bg = QRadialGradient(QPointF(cx, cy), max(w, h) * 0.8)
        bg.setColorAt(0, QColor(11, 26, 44))
        bg.setColorAt(0.5, QColor(5, 10, 20))
        bg.setColorAt(1, QColor(3, 5, 10))
        p.fillRect(self.rect(), bg)
        p.setPen(Qt.NoPen)
        for sx, sy, sz in self.stars:
            a = 35 + 90 * (0.5 + 0.5 * math.sin(b.t * (0.6 + sz) + sz * 40))
            p.setBrush(QColor(200, 235, 255, int(a)))
            p.drawEllipse(QPointF(sx * w, sy * h), 0.5 + sz, 0.5 + sz)
        aura = QRadialGradient(QPointF(cx, cy), R * (2.3 + 0.35 * b.energy + 0.2 * b.speak))
        aura.setColorAt(0, QColor(base[0], base[1], base[2], int(60 + 50 * b.energy)))
        aura.setColorAt(0.45, QColor(139, 123, 255, 22 + int(20 * b.speak)))
        aura.setColorAt(1, QColor(0, 0, 0, 0))
        p.setBrush(aura)
        p.drawEllipse(QPointF(cx, cy), R * 2.6, R * 2.6)
        b.paint(p, cx, cy, R, True)
        p.setBrush(Qt.NoBrush)
        p.setPen(QPen(QColor(base[0], base[1], base[2], 45), 1.0))
        p.drawEllipse(QPointF(cx, cy), R * 1.2, R * 1.2)
        p.setPen(QPen(QColor(base[0], base[1], base[2], 200), 2.0, Qt.SolidLine, Qt.RoundCap))
        p.drawArc(QRectF(cx - R * 1.2, cy - R * 1.2, R * 2.4, R * 2.4), int(-b.t * 55 * 16), 62 * 16)
        p.end()


class FloatingOrb(QWidget):
    """Small always-on-top orb shown while the main window is closed or minimised."""

    activated = Signal()
    menu_requested = Signal(QPoint)
    moved = Signal(int, int)

    def __init__(self) -> None:
        super().__init__(None, Qt.Tool | Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.NoDropShadowWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.WA_ShowWithoutActivating)
        self.setFixedSize(132, 132)
        self.setToolTip("AURIX — click to open · drag to move · right-click for menu")
        self.blob = NeuralBlob(64, False, 9)
        self.badge = 0
        self._press = None
        self._moved = False
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._tick)

    def place_default(self) -> None:
        screen = QApplication.primaryScreen().availableGeometry()
        self.move(screen.right() - self.width() - 24, screen.bottom() - self.height() - 24)

    def set_online(self, v: bool) -> None:
        self.blob.online = v

    def set_thinking(self, v: bool) -> None:
        self.blob.thinking = v

    def set_speaking(self, v: bool) -> None:
        self.blob.speaking = v

    def pulse(self) -> None:
        self.blob.kick = 1.0

    def fire(self, key: str, inbound: bool = False) -> None:
        self.blob.fire(key, inbound)

    def set_badge(self, n: int) -> None:
        self.badge = n
        self.update()

    def showEvent(self, e) -> None:  # noqa: N802
        self.timer.start(40)
        super().showEvent(e)

    def hideEvent(self, e) -> None:  # noqa: N802
        self.timer.stop()
        super().hideEvent(e)

    def _tick(self) -> None:
        self.blob.step(0.04)
        self.blob.rot_y += 0.012 + 0.02 * self.blob.energy
        self.update()

    def mousePressEvent(self, e) -> None:  # noqa: N802
        if e.button() == Qt.LeftButton:
            self._press = e.globalPosition().toPoint() - self.frameGeometry().topLeft()
            self._moved = False
        elif e.button() == Qt.RightButton:
            self.menu_requested.emit(e.globalPosition().toPoint())

    def mouseMoveEvent(self, e) -> None:  # noqa: N802
        if self._press is not None and e.buttons() & Qt.LeftButton:
            target = e.globalPosition().toPoint() - self._press
            if (target - self.frameGeometry().topLeft()).manhattanLength() > 3:
                self._moved = True
            self.move(target)

    def mouseReleaseEvent(self, e) -> None:  # noqa: N802
        if e.button() == Qt.LeftButton and self._press is not None:
            self._press = None
            if self._moved:
                self.moved.emit(self.x(), self.y())
            else:
                self.activated.emit()

    def paintEvent(self, event) -> None:  # noqa: N802
        del event
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        b = self.blob
        base = CYAN if b.online else GREY
        c = QPointF(66, 66)
        g = QRadialGradient(c, 64)
        g.setColorAt(0, QColor(base[0], base[1], base[2], int(70 + 50 * b.energy + 40 * b.speak)))
        g.setColorAt(0.55, QColor(139, 123, 255, 28))
        g.setColorAt(1, QColor(0, 0, 0, 0))
        p.setPen(Qt.NoPen)
        p.setBrush(g)
        p.drawEllipse(c, 64, 64)
        p.setBrush(QColor(5, 10, 20, 215))
        p.drawEllipse(c, 40, 40)
        b.paint(p, 66, 66, 33, False)
        p.setBrush(Qt.NoBrush)
        p.setPen(QPen(QColor(base[0], base[1], base[2], 170), 1.6))
        p.drawEllipse(c, 40, 40)
        if self.badge:
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(255, 120, 190))
            p.drawEllipse(QPointF(104, 28), 10, 10)
            p.setPen(QColor(10, 10, 20))
            p.setFont(QFont("Segoe UI", 7, QFont.Bold))
            p.drawText(QRectF(94, 18, 20, 20), Qt.AlignCenter, str(min(self.badge, 9)))
        p.end()


class Toast(QWidget):
    """Speech-bubble notification that appears next to the orb."""

    clicked = Signal()

    def __init__(self) -> None:
        super().__init__(None, Qt.Tool | Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.NoDropShadowWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.WA_ShowWithoutActivating)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(16, 12, 16, 12)
        lay.setSpacing(4)
        self.title = QLabel()
        self.title.setStyleSheet("color:#5ef0ff;font:700 7pt 'Segoe UI';letter-spacing:1.4px;")
        self.body = QLabel()
        self.body.setWordWrap(True)
        self.body.setStyleSheet("color:#e6f7fc;font:9pt 'Segoe UI';")
        self.body.setFixedWidth(300)
        lay.addWidget(self.title)
        lay.addWidget(self.body)
        self.timer = QTimer(self)
        self.timer.setSingleShot(True)
        self.timer.timeout.connect(self.hide)

    def show_message(self, title: str, text: str, anchor: QWidget, ms: int = 9000) -> None:
        self.title.setText(title.upper()[:48])
        self.body.setText(text if len(text) < 260 else text[:257] + "…")
        self.adjustSize()
        screen = QApplication.primaryScreen().availableGeometry()
        x = anchor.x() - self.width() - 8
        if x < screen.left():
            x = anchor.x() + anchor.width() + 8
        y = max(screen.top() + 8, min(anchor.y() + anchor.height() // 2 - self.height() // 2, screen.bottom() - self.height() - 8))
        self.move(x, y)
        self.show()
        self.timer.start(ms)

    def paintEvent(self, event) -> None:  # noqa: N802
        del event
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setPen(QPen(QColor(40, 100, 125), 1))
        p.setBrush(QColor(7, 15, 26, 240))
        p.drawRoundedRect(QRectF(0.5, 0.5, self.width() - 1, self.height() - 1), 14, 14)
        p.end()

    def mousePressEvent(self, e) -> None:  # noqa: N802
        self.hide()
        self.clicked.emit()
