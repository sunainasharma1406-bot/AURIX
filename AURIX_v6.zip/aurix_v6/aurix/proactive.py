"""AURIX v6 proactive layer: AURIX tells you things on its own.

Weather and AQI (Open-Meteo, no key), headlines (Google News RSS, no key), PC health (psutil if present),
wellness reminders and a spoken briefing. Everything is optional and can be switched off in Assistant settings.
"""
from __future__ import annotations

import ctypes
import shutil
import sys
import time
import xml.etree.ElementTree as ET
from datetime import datetime
from email.utils import parsedate_to_datetime
from pathlib import Path
from typing import Any, Callable

import requests
from PySide6.QtCore import QObject, QThread, QTimer, Signal

UA = {"User-Agent": "AURIX/6 (+local personal assistant)"}
NEWS_FEEDS = [
    ("Top", "https://news.google.com/rss?hl=en-IN&gl=IN&ceid=IN:en"),
    ("Tech", "https://news.google.com/rss/headlines/section/topic/TECHNOLOGY?hl=en-IN&gl=IN&ceid=IN:en"),
    ("Science", "https://news.google.com/rss/headlines/section/topic/SCIENCE?hl=en-IN&gl=IN&ceid=IN:en"),
]
WMO = {0: ("Clear sky", "☀"), 1: ("Mostly clear", "🌤"), 2: ("Partly cloudy", "⛅"), 3: ("Overcast", "☁"), 45: ("Fog", "🌫"), 48: ("Fog", "🌫"),
       51: ("Light drizzle", "🌦"), 53: ("Drizzle", "🌦"), 55: ("Heavy drizzle", "🌧"), 61: ("Light rain", "🌧"), 63: ("Rain", "🌧"),
       65: ("Heavy rain", "🌧"), 71: ("Snow", "❄"), 80: ("Rain showers", "🌦"), 81: ("Rain showers", "🌧"), 82: ("Violent showers", "⛈"),
       95: ("Thunderstorm", "⛈"), 96: ("Thunderstorm, hail", "⛈"), 99: ("Thunderstorm, hail", "⛈")}


def wmo(code: int) -> tuple[str, str]:
    return WMO.get(code) or WMO.get(max(k for k in WMO if k <= code), ("Unsettled", "☁"))


def aqi_label(aqi: float | None) -> str:
    if aqi is None:
        return "unknown"
    for limit, name in ((50, "good"), (100, "moderate"), (150, "unhealthy for sensitive people"), (200, "unhealthy"), (300, "very unhealthy")):
        if aqi <= limit:
            return name
    return "hazardous"


class WeatherWorker(QThread):
    done = Signal(dict)
    failed = Signal(str)

    def __init__(self, place: str, lat: float | None, lon: float | None) -> None:
        super().__init__()
        self.place, self.lat, self.lon = place, lat, lon

    def run(self) -> None:
        try:
            lat, lon, name = self.lat, self.lon, self.place
            if lat is None or lon is None:
                geo = requests.get("https://geocoding-api.open-meteo.com/v1/search", params={"name": self.place, "count": 1, "language": "en"}, headers=UA, timeout=10)
                geo.raise_for_status()
                found = (geo.json().get("results") or [])
                if not found:
                    raise RuntimeError(f"Could not find a place called '{self.place}'.")
                lat, lon, name = found[0]["latitude"], found[0]["longitude"], found[0].get("name", self.place)
            fc = requests.get("https://api.open-meteo.com/v1/forecast", headers=UA, timeout=12, params={
                "latitude": lat, "longitude": lon, "timezone": "auto", "forecast_days": 1, "forecast_hours": 6,
                "current": "temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m,is_day",
                "daily": "temperature_2m_max,temperature_2m_min,precipitation_probability_max,uv_index_max",
                "hourly": "precipitation_probability"})
            fc.raise_for_status()
            data = fc.json()
            cur, day = data["current"], data["daily"]
            aq: dict[str, Any] = {}
            try:
                aq = requests.get("https://air-quality-api.open-meteo.com/v1/air-quality", headers=UA, timeout=8,
                                  params={"latitude": lat, "longitude": lon, "current": "us_aqi,pm2_5"}).json().get("current", {})
            except (requests.RequestException, ValueError):
                pass
            hourly = [x for x in (data.get("hourly", {}).get("precipitation_probability") or []) if x is not None]
            self.done.emit({
                "place": name, "lat": lat, "lon": lon, "temp": cur["temperature_2m"], "feels": cur["apparent_temperature"],
                "humidity": cur["relative_humidity_2m"], "wind": cur["wind_speed_10m"], "code": int(cur["weather_code"]),
                "hi": day["temperature_2m_max"][0], "lo": day["temperature_2m_min"][0],
                "rain": (day.get("precipitation_probability_max") or [0])[0] or 0, "rain_soon": max(hourly[:4] or [0]),
                "uv": (day.get("uv_index_max") or [None])[0], "aqi": aq.get("us_aqi"), "pm25": aq.get("pm2_5"), "ts": time.time()})
        except (requests.RequestException, KeyError, ValueError, RuntimeError, IndexError) as exc:
            self.failed.emit(str(exc)[:200])


class NewsWorker(QThread):
    done = Signal(list)
    failed = Signal(str)

    def run(self) -> None:
        items: list[dict] = []
        errors = 0
        for cat, url in NEWS_FEEDS:
            try:
                r = requests.get(url, headers=UA, timeout=12)
                r.raise_for_status()
                root = ET.fromstring(r.content[:1_500_000])
                for it in list(root.iter("item"))[:8]:
                    title = (it.findtext("title") or "").strip()
                    link = (it.findtext("link") or "").strip()
                    if not title or not link.startswith("http"):
                        continue
                    head, _, source = title.rpartition(" - ")
                    try:
                        ts = parsedate_to_datetime(it.findtext("pubDate") or "").timestamp()
                    except (TypeError, ValueError):
                        ts = 0.0
                    items.append({"title": head or title, "source": source if head else "", "url": link, "cat": cat, "ts": ts})
            except (requests.RequestException, ET.ParseError):
                errors += 1
        if not items:
            self.failed.emit("News feeds unreachable" if errors else "No headlines found")
            return
        seen, out = set(), []
        for it in sorted(items, key=lambda x: -x["ts"]):
            key = it["title"].lower()[:60]
            if key not in seen:
                seen.add(key)
                out.append(it)
        self.done.emit(out[:24])


def system_snapshot() -> dict[str, Any]:
    d: dict[str, Any] = {"cpu": None, "ram": None, "disk": None, "battery": None, "plugged": None}
    try:
        import psutil  # type: ignore
        d["cpu"] = psutil.cpu_percent(interval=None)
        d["ram"] = psutil.virtual_memory().percent
        bat = psutil.sensors_battery()
        if bat is not None:
            d["battery"], d["plugged"] = bat.percent, bat.power_plugged
    except Exception:  # noqa: BLE001 - psutil is optional
        if sys.platform.startswith("win"):
            try:
                class MS(ctypes.Structure):
                    _fields_ = [("l", ctypes.c_ulong), ("load", ctypes.c_ulong)] + [(n, ctypes.c_ulonglong) for n in ("a", "b", "c", "d", "e")] + [("x", ctypes.c_ulonglong)]
                ms = MS()
                ms.l = ctypes.sizeof(MS)
                ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(ms))
                d["ram"] = float(ms.load)
            except Exception:  # noqa: BLE001
                pass
    try:
        du = shutil.disk_usage(Path.home().anchor or "/")
        d["disk"] = du.used / du.total * 100
    except OSError:
        pass
    return d


class ProactiveEngine(QObject):
    """Schedules briefings and alerts. Emits `event(kind, title, text, speak)`."""

    event = Signal(str, str, str, bool)
    weather_updated = Signal(dict)
    news_updated = Signal(list)
    health_updated = Signal(dict)
    status = Signal(str)

    def __init__(self, get_settings: Callable[[], dict], save_settings: Callable[[dict], None], parent: QObject | None = None) -> None:
        super().__init__(parent)
        self.get, self.save = get_settings, save_settings
        self.wx: dict | None = None
        self.news: list[dict] = []
        self.seen: set[str] = set()
        self.health: dict = {}
        self.started = time.time()
        self.last: dict[str, float] = {}
        self.cpu_hot = 0
        self._wx_worker: WeatherWorker | None = None
        self._news_worker: NewsWorker | None = None
        self._briefed = False
        for attr, ms, fn in (("t_wx", 20 * 60_000, self.refresh_weather), ("t_news", 8 * 60_000, self.refresh_news),
                             ("t_health", 5_000, self._health_tick), ("t_well", 60_000, self._wellness_tick)):
            t = QTimer(self)
            t.timeout.connect(fn)
            t.start(ms)
            setattr(self, attr, t)

    # ---- helpers
    def _on(self, key: str, default: bool = True) -> bool:
        return bool(self.get().get("proactive_enabled", True)) and bool(self.get().get(key, default))

    def quiet(self) -> bool:
        s, e, h = int(self.get().get("quiet_start", 23)), int(self.get().get("quiet_end", 7)), datetime.now().hour
        return (h >= s or h < e) if s > e else (s <= h < e)

    def _cool(self, key: str, seconds: float) -> bool:
        now = time.time()
        if now - self.last.get(key, 0) < seconds:
            return False
        self.last[key] = now
        return True

    def _emit(self, kind: str, title: str, text: str, speak: bool = True) -> None:
        loud = speak and bool(self.get().get("proactive_speak", True)) and not self.quiet()
        self.event.emit(kind, title, text, loud)

    # ---- lifecycle
    def start(self) -> None:
        QTimer.singleShot(1500, self.refresh_weather)
        QTimer.singleShot(2500, self.refresh_news)
        QTimer.singleShot(14_000, lambda: self.briefing(auto=True))

    def refresh_weather(self) -> None:
        if not self._on("weather_enabled") or (self._wx_worker is not None and self._wx_worker.isRunning()):
            return
        s = self.get()
        self._wx_worker = WeatherWorker(str(s.get("weather_place", "Kalyan")), s.get("weather_lat"), s.get("weather_lon"))
        self._wx_worker.done.connect(self._on_weather)
        self._wx_worker.failed.connect(lambda e: self.status.emit("Weather unavailable: " + e))
        self._wx_worker.start()

    def refresh_news(self) -> None:
        if not self._on("news_enabled") or (self._news_worker is not None and self._news_worker.isRunning()):
            return
        self._news_worker = NewsWorker()
        self._news_worker.done.connect(self._on_news)
        self._news_worker.failed.connect(lambda e: self.status.emit("News unavailable: " + e))
        self._news_worker.start()

    def stop_workers(self) -> None:
        for w in (self._wx_worker, self._news_worker):
            if w is not None and w.isRunning():
                w.wait(2500)

    # ---- data handlers
    def _on_weather(self, d: dict) -> None:
        self.wx = d
        s = self.get()
        if s.get("weather_lat") != d["lat"]:
            s["weather_lat"], s["weather_lon"] = d["lat"], d["lon"]
            self.save(s)
        self.weather_updated.emit(d)
        today = datetime.now().strftime("%Y%m%d")
        name = d["place"]
        if d["rain_soon"] >= 60 and self._cool("rain" + today, 6 * 3600):
            self._emit("weather", f"Rain likely · {name}", f"There is a {int(d['rain_soon'])}% chance of rain in the next few hours. Keep an umbrella handy.")
        if d["temp"] >= 38 and self._cool("heat" + today, 12 * 3600):
            self._emit("weather", f"Heat alert · {name}", f"It is {d['temp']:.0f} degrees outside. Drink water and avoid the midday sun.")
        if d["code"] >= 95 and self._cool("storm" + today, 6 * 3600):
            self._emit("weather", f"Thunderstorm · {name}", "A thunderstorm is reported nearby. Unplug sensitive hardware and stay indoors.")
        if (d.get("aqi") or 0) > 150 and self._cool("aqi" + today, 12 * 3600):
            self._emit("health", f"Poor air quality · {name}", f"The air quality index is {int(d['aqi'])}, which is {aqi_label(d['aqi'])}. Limit outdoor activity and consider a mask.")

    def _on_news(self, items: list) -> None:
        first = not self.seen
        new = [i for i in items if i["title"].lower()[:60] not in self.seen]
        self.seen.update(i["title"].lower()[:60] for i in items)
        self.news = items
        self.news_updated.emit(items)
        if not first and new and self._on("news_alerts") and self._cool("newsalert", 5 * 60):
            top = sorted(new, key=lambda i: (i["cat"] != "Top", -i["ts"]))[0]
            self._emit("news", f"New · {top['source'] or top['cat']}", top["title"])

    def _health_tick(self) -> None:
        if not self._on("health_alerts"):
            return
        h = system_snapshot()
        self.health = h
        self.health_updated.emit(h)
        if h["battery"] is not None and h["battery"] <= 20 and not h["plugged"] and self._cool("bat", 30 * 60):
            self._emit("health", "Battery low", f"Battery is at {h['battery']:.0f} percent. Plug in your charger.")
        if h["ram"] is not None and h["ram"] >= 92 and self._cool("ram", 20 * 60):
            self._emit("health", "Memory almost full", f"RAM usage is {h['ram']:.0f} percent. Close heavy apps or the model may slow down.")
        if h["disk"] is not None and h["disk"] >= 92 and self._cool("disk", 6 * 3600):
            self._emit("health", "Disk nearly full", f"Your system drive is {h['disk']:.0f} percent full.")
        self.cpu_hot = self.cpu_hot + 1 if (h["cpu"] or 0) >= 93 else 0
        if self.cpu_hot >= 8 and self._cool("cpu", 20 * 60):
            self._emit("health", "CPU running hot", "The processor has been near 100 percent for a while. A break for the PC might help.")

    def _wellness_tick(self) -> None:
        if not self._on("wellness_enabled"):
            return
        mins = (time.time() - self.started) / 60
        every = max(20, int(self.get().get("break_minutes", 50)))
        if mins >= every and self._cool("break", every * 60):
            self._emit("wellness", "Time for a break", "You have been at the screen for a while. Stand up, stretch, and look at something far away for twenty seconds.")
        elif mins >= 90 and self._cool("water", 90 * 60):
            self._emit("wellness", "Hydration check", "Drink a glass of water. Your brain works better when you are hydrated.")
        now = datetime.now()
        if (now.hour == 0 and now.minute >= 30 or 1 <= now.hour < 4) and self._cool("late" + now.strftime("%Y%m%d"), 20 * 3600):
            self._emit("wellness", "It is getting very late", "Consider wrapping up and sleeping. Rest is when you actually retain what you learned today.", speak=True)

    # ---- briefing
    def briefing(self, auto: bool = False) -> None:
        if auto:
            if self._briefed or not self._on("briefing_on_start"):
                return
            self._briefed = True
        now = datetime.now()
        name = str(self.get().get("user_name", "")).strip()
        part = "morning" if now.hour < 12 else "afternoon" if now.hour < 17 else "evening"
        lines = [f"It's {now.strftime('%A, %d %B')}, {now.strftime('%I:%M %p').lstrip('0')}."]
        wx = self.wx
        if wx:
            cond = wmo(wx["code"])[0].lower()
            lines.append(f"In {wx['place']} it's {wx['temp']:.0f} degrees with {cond}. Today's high is {wx['hi']:.0f}, low {wx['lo']:.0f}, rain chance {int(wx['rain'])} percent.")
            if wx.get("aqi") is not None:
                lines.append(f"Air quality is {aqi_label(wx['aqi'])}.")
        elif self._on("weather_enabled"):
            lines.append("Weather is not available right now.")
        h = self.health or system_snapshot()
        if h.get("battery") is not None:
            lines.append(f"Battery {h['battery']:.0f} percent{'' if h.get('plugged') else ', on battery'}.")
        if h.get("ram") is not None:
            lines.append(f"Memory use {h['ram']:.0f} percent.")
        if self.news:
            top = sorted(self.news, key=lambda i: (i["cat"] != "Top", -i["ts"]))[:2]
            lines.append("Top headlines: " + " ... ".join(i["title"] for i in top) + ".")
        title = f"Good {part}" + (f", {name}" if name else "")
        self.last["briefing"] = time.time()
        self.event.emit("briefing", title, " ".join(lines), bool(self.get().get("proactive_speak", True)) and (not auto or not self.quiet()))
