"""AURIX v6 — local-first personal intelligence."""
